/* 2148, Sun 29 Jun 08 (NZST)

   iat-12_queue.h:  Defines for owtmon-style queues

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2013 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


/* In these routines, think of the queue like an array; 
  'head' is element 0, 'tail' is the highest-index element.

   Uni-directional queues have *next in their object struct.
   Bi-directional queues have *next and *prev in their object struct.

   [ gcc -E to only run preprocessor] */


/* (1) Declare global structs, usable in all .c files
       and templates for functions to work with them */

#define iat_queue_declare_globals(n)  /* Queue struct and methods */ \
struct n##_queue { \
   struct n *head, *tail; \
   pthread_mutex_t mutex; \
   int length; \
   }; \
\
void init_##n##_queue(struct n##_queue *q); \
void n##_q_lock(struct n##_queue *q); \
void n##_q_unlock(struct n##_queue *q); \
void n##_push(struct n##_queue *q, struct n *object);  /* Add to tail */ \
void n##_unshift(struct n##_queue *q, struct n *object); /* Add to head */ \
void n##_append(struct n##_queue *q1, \
   struct n##_queue *q2);  /* Append to tail */ \
struct n *n##_shift(struct n##_queue *q);  /* Remove from head */ \
void n##_walk_down(struct n##_queue *q,  /* Head to tail */ \
   int (*f)(struct n *obj)); \
int n##_queue_ok(struct n##_queue *q, int lock, int qarg)

#define iat_queue2_declare_globals(n2)  /* Queue struct and methods */ \
struct n2##_queue { \
   struct n2 *head, *tail; \
   pthread_mutex_t mutex; \
   int length; \
   }; \
\
void init_##n2##_queue(struct n2##_queue *q); \
void n2##_q_lock(struct n2##_queue *q); \
void n2##_q_unlock(struct n2##_queue *q); \
void n2##_push(struct n2##_queue *q, struct n2 *object);  /* Add to tail */ \
struct n2 *n2##_pop(struct n2##_queue *q);  /* Remove from tail */ \
void n2##_unshift(struct n2##_queue *q, struct n2 *object); /* Add to head */ \
struct n2 *n2##_shift(struct n2##_queue *q);  /* Remove from head */	\
struct n2 *n2##_extract(struct n2##_queue *q, struct n2 *object); \
                                /* Remove arbitrary object */ \
void n2##_walk_down(struct n2##_queue *q,  /* Head to tail */ \
   int (*f)(struct n2 *obj)); \
void n2##_walk_up(struct n2##_queue *q,  /* Tail to head */ \
   int (*f)(struct n2 *obj));

/* (2) Declare actual functions (matching the templates) */

#define iat_queue_declare_functions(n)  /* Queue struct and methods */ \
void init_##n##_queue(struct n##_queue *q) { \
   init_mutex(&q->mutex, "n##_mutex"); \
   q->head = q->tail = NULL;  q->length = 0; \
   } \
\
void n##_q_lock(struct n##_queue *q) { \
   mutex_lock("n##_q_lock", &q->mutex); \
   } \
void n##_q_unlock(struct n##_queue *q) { \
   mutex_unlock("n##_q_lock", &q->mutex); \
   } \
\
void n##_push(struct n##_queue *q, struct n *object) {  /* Add to tail */ \
   if (object == NULL) quack(2002); \
   if (q->length != 0) { \
      if (q->head == NULL || q->tail == NULL) quack(2004); \
      } \
   else { \
      if (q->head != NULL || q->tail != NULL) quack(2006); \
      } \
   object->next = NULL; \
   if (q->tail != NULL) q->tail->next = object; \
   else q->head = object; \
   q->tail = object;  q->length += 1; \
   } \
\
void n##_unshift(struct n##_queue *q, struct n *object) {  /* Add to head */ \
   if (object == NULL) quack(2002); \
   if (q->length != 0) { \
      if (q->head == NULL || q->tail == NULL) quack(2004); \
      } \
   else { \
      if (q->head != NULL || q->tail != NULL) quack(2006); \
      } \
   if (q->head == NULL) { \
      object->next = NULL;  q->tail = object; \
      } \
   else object->next = q->head; \
   q->head = object;  q->length += 1; \
   } \
void n##_append(struct n##_queue *q1, \
   struct n##_queue *q2) {  /* Append to tail */ \
   if (q1->length != 0) { \
      if (q1->head == NULL || q1->tail == NULL) quack(2004); \
      } \
   else { \
      if (q1->head != NULL || q1->tail != NULL) quack(2006); \
      } \
   if (q2->length != 0) { \
      if (q2->head == NULL || q2->tail == NULL) quack(2008); \
      } \
   else { \
      if (q2->head != NULL || q2->tail != NULL) quack(2012); \
      } \
   if (q2->length == 0) return; \
   if (q1->head == NULL) q1->head = q2->head; \
   else  q1->tail->next = q2->head; \
   q1->tail = q2->tail;  q1->length += q2->length; \
   q2->head = q2->tail = NULL;  q2->length = 0; \
   } \
struct n *n##_shift(struct n##_queue *q) {  /* Remove from head */ \
   struct n *obj; \
   if (q->length != 0) { \
      if (q->head == NULL || q->tail == NULL) quack(2014); \
      if (q->head->next == NULL && q->length != 1) quack(2015); \
      } \
   else { \
      if (q->head != NULL || q->tail != NULL) quack(2016); \
      } \
   if (q->head == NULL) obj = NULL;  /* 0 in queue */ \
   else { \
      obj = q->head;  q->length -= 1; \
      if (q->head == q->tail)  /* 1 in queue */ \
         q->head = q->tail = NULL; \
      else  /* >1 in queue */ \
 	 q->head = obj->next; \
      obj->next = NULL; \
      } \
   return obj; \
   } \
\
void n##_walk_down(struct n##_queue *q,  /* Head to tail */ \
      int (*f)(struct n *obj)) { \
   struct n *op, *n_op; \
   for (op = q->head; op != NULL; op = n_op) { \
      n_op = op->next; \
      if (f(op)) break; \
      } \
   } \
\
int n##_queue_ok(struct n##_queue *q, int lock, int qarg) { \
   int bad, count = 0; \
   struct n *op; \
   if (lock) mutex_lock("n##_q_lock", &q->mutex); \
   op = q->head;  for (;;) { \
      if (op == NULL) break; \
      count += 1; \
      op = op->next; \
      } \
   bad = count != q->length || (q->length == 1 && (q->head != q->tail)); \
   if (lock) mutex_unlock("n##_q_lock", &q->mutex); \
   if (bad) quack(qarg); \
   return !bad; \
   }

#define iat_queue2_declare_functions(n2)  /* Queue struct and methods */ \
struct n2 *get_##n(void) { \
   return (struct n2 *)malloc(sizeof(struct n)); \
   } \
void free_##n(struct n2 *object) { \
   free(object); \
   } \
void init_##n2##_queue(struct n2##_queue *q) { \
   init_mutex(&q->mutex, "n2##_mutex"); \
   q->head = q->tail = NULL;  q->length = 0; \
   } \
\
void n2##_q_lock(struct n2##_queue *q) { \
   mutex_lock("n2##_q_lock", &q->mutex); \
   } \
void n2##_q_unlock(struct n2##_queue *q) {	\
   mutex_unlock("n2##_q_lock", &q->mutex); \
   } \
\
void n2##_push(struct n2##_queue *q, struct n2 *object) {  /* Add to tail */ \
   if ((q->head == NULL || q->tail == NULL) && q->length != 0) quack(2202); \
   object->next = NULL;  object->prev = q->tail; \
   if (q->tail != NULL) q->tail->next = object; \
   else q->head = object; \
   q->tail = object;  q->length += 1; \
   } \
\
void n2##_unshift(struct n2##_queue *q, struct n2 *object) { /* Add to head */ \
   if ((q->head == NULL || q->tail == NULL) && q->length != 0) quack(2212); \
   object->next = q->head;  object->prev = NULL; \
   if (q->head != NULL) q->head->prev = object; \
   else q->tail = object; \
   q->head = object;  q->length += 1; \
   if ((q->head == NULL || q->tail == NULL) && q->length != 0) quack(2214); \
   } \
\
struct n2 *n2##_shift(struct n2##_queue *q) {  /* Remove from head */ \
   struct n2 *obj; \
   if ((q->head == NULL || q->tail == NULL) && q->length != 0) quack(2022); \
   if (q->head == NULL) obj = NULL;  /* 0 in queue */ \
   else { \
      obj = q->head;  q->length -= 1; \
      if (q->head == q->tail) {  /* 1 in queue */ \
         q->head = q->tail = NULL; \
         } \
      else {  /* >1 in queue */ \
 	 q->head = obj->next;  q->head->prev = NULL; \
         } \
      } \
   if ((q->head == NULL || q->tail == NULL) && q->length != 0) quack(2024); \
   return obj; \
   } \
\
struct n2 *n2##_extract(struct n2##_queue *q, struct n2 *object) { \
   /* Remove arbitrary object.  CAUTION: no checks of link validity! */ \
   if ((q->head == NULL || q->tail == NULL) && q->length != 0) quack(2026); \
   if (object->prev == NULL) { \
      if (q->head != object) quack(1001); \
      } \
   else if (object->prev->next != object) quack(1002); \
   if (object->next == NULL) { \
      if (q->tail != object) quack(1003); \
      } \
   else if (object->next->prev != object) quack(1004); \
   if (object->prev != NULL) \
      object->prev->next = object->next; \
   else q->head = object->next; \
   if (object->next != NULL) \
      object->next->prev = object->prev; \
   else q->tail = object->prev; \
   q->length -= 1; \
   return object; \
   } \
\
struct n2 *n2##_pop(struct n2##_queue *q) {  /* Remove from tail */ \
   struct n2 *obj; \
   if (q->tail == NULL) obj = NULL;  /* 0 in queue */ \
   else { \
      obj = q->tail;  q->length -= 1; \
      if (q->head == q->tail) {  /* 1 in queue */ \
         q->head = q->tail = NULL; \
         } \
      else {  /* >1 in queue */ \
 	 q->tail = obj->prev;  q->tail->next = NULL; \
         } \
      } \
   return obj; \
   } \
\
void n2##_walk_down(struct n2##_queue *q,  /* Head to tail */ \
      int (*f)(struct n2 *obj)) { \
   struct n2 *op, *n_op; \
   for (op = q->head; op != NULL; op = n_op) { \
      n_op = op->next; \
      if (f(op)) break; \
      } \
   } \
\
void n2##_walk_up(struct n2##_queue *q,  /* Tail to head */ \
      int (*f)(struct n2 *obj)) { \
   struct n2 *op, *n_op; \
   for (op = q->tail; op != NULL; op = n_op) { \
      n_op = op->prev; \
      if (f(op)) break; \
      } \
   }

/* (3) Define variables within a .c file */

#define iat_queue_declare_space(q, n) \
struct n##_queue q;

#define iat_queue2_declare_space(q, n2) \
struct n2##_queue q;
