
//  gcc -o libsmee_options -DIATMON libsmee_options.c

#include "iat.h"

int main() {
   FILE *of = fopen("ls_options.txt", "w");   
   fprintf(of, "libsmee build option values:\n");
   fprintf(of, "   IATversion     = %s\n", IATversion);
   fprintf(of, "   SOURCETIMEOUTS = %d\n", SOURCETIMEOUTS);
   fprintf(of, "   MXFLOWWATCHERS = %d\n", DFMXFLOWWATCHERS);
   fprintf(of, "   IATMON         = %d\n", IATMON);
   fprintf(of, "   NON_CONF_TEST  = %d\n", NON_CONF_TEST);
   fclose(of);
   }
