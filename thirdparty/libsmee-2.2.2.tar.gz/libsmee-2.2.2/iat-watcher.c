/* 1154, Wed 23 May 12 (PDT)
   1541, Thu 17 Mar 11 (PDT)
   1552, Thu 17 Jun 10 (NZST)
   1955, Thu 22 Apr 10 (PDT)
   1330, Fri  1 Feb 08 (NZDT)

   iat-watcher.c:  Packet and Source routines for iatmon

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2013 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "iat.h"

/* Globals for SRI code to generate Conficker port numbers (in conf-sri.c) */
typedef union {
   int16_t s16[8];  uint16_t u16[8];  int32_t s32[4];
   } result_t;
int portgen(int ip, result_t *res, int week);

uint32_t date_seed;

void set_date_seed(uint32_t ts) {
   /* Emile's python code ...
      date_seed = ((((uint64_t)ts - 345600) * 1861606989) >> 32) >> 18; */
   /* Nevil's C code: following line seems to be equivalent to
      date_seed = ((uint64_t)ts - 4*24*3600)/(7*24*3600); */
   date_seed = (uint32_t)(((((uint64_t)ts - 345600) * 1861606989) >> 32) >> 18);
   }

void check_src_nulls(struct source_queue *sq, struct source *sp);
int check_source_chains(char const *msg, struct source_queue *sq);

char time_buf[30];
char *fmt_time(int ts) {
   time_t tt = ts;
   struct tm *t = gmtime(&tt);
   asctime_r(t, time_buf);
   time_buf[24] = '\0';
   return time_buf;
   }

static uint32_t last_timerec_sec = 0;
static void output_time_record(uint32_t now_ts) {
   log_msg(user_data, LOG_WARNING, -1, "#Time: %s  %s  Flows from %lu to %lu",
      fmt_time(now_ts), iat_trace_name,
      (unsigned long)last_timerec_sec, (unsigned long)now_ts);
   last_timerec_sec = now_ts;
   }

static void fdf_hdr_string(char *buf) {
   sprintf(buf, "##iatmon-%s: -c%u %s -s%u  starting at %s",
      IATversion, time_rec_interval, iat_trace_name,
      mx_sources, fmt_time(start_ts));
   }

static void output_fdf_hdr(void) {
   char hdr_str[MXSTRMTXTLEN];
   fdf_hdr_string(hdr_str);
   log_msg(user_data, LOG_WARNING, -1, hdr_str);
   }
char *iat_file_header(void) {
   char *msg = malloc(MXSTRMTXTLEN);
   fdf_hdr_string(msg);
   return msg;
   }

int rake_idle_sources(struct flow_watcher_control *fw,
      uint32_t now_ts) {
   struct source_queue *sq = &fw->sq;
   uint32_t min_idle_s;
   struct source *sp;
   int keep, examined = 0, freed = 0;

#if SC_DEBUG >= 2
   fprintf(stderr, "  === check_timeouts(%d), ts=%u\n", fw->id, now_ts);
#endif
   min_idle_s = now_ts - TOO_MANY_TIMEOUT;
#if SC_DEBUG >= 1
   check_source_chains("--- starting rake_idle_streans", sq);
#endif
   for (;;) {
      sp = source_shift(sq);  /* Remove source from head */
      if (sp == NULL) break;  /* End of queue */
      if (sp->d.si->last_s > min_idle_s) {
         source_unshift(sq, sp);  /* Put it back! */
         break;  /* Hasn't been queued long enough; stop checking */
         }
      else {  /* Could be inactive, can we recover it? */
         examined += 1;
         keep = sp->totp > MN_PKTS_FOR_DISCARD;
         }
      if (keep) source_push(sq, sp);  /* Add source to tail */
         /* We won't waste time tesing it until it drifts back
            to the head of the queue.  That means we no longer               
            have the queue in (approximnate) LastTime order */
      else {  /* Discard this source */
         update_ua_stats(sp);  /* Un-analysed source info */
         update_summary_info(sp);
         iat_ht_delete(fw->sh_table, sp);  /* Remove from hash table */
         iat_free_source(sp);
         freed += 1;
         if (freed == MN_SOURCES_TO_FREE) break;
         //      check_source_chains("--- after timed out", sq);
         }
      }
#if SC_DEBUG >= 2
   fprintf(stderr, "==== sources: %d examined, %d freed.  %d active sv4s\n",
       examined, freed, sources_active());
#endif
   return freed;
   }

int coss(struct source *sp)
{  /* Return 0 to continue, 1 to stop walking */
   struct flow_watcher_control *fw = fwa[sp->fw_nbr];
   fw->state_counts[sp->state] += 1;
   return 0;
   }

void count_source_states(char *buf, struct flow_watcher_control *fw,
      const char *msg) {
   int j, x, y;
   for (j = 0; j != SS_n_states; j += 1) fw->state_counts[j] = 0;
   source_walk_down(&fw->sq, coss);
   source_walk_down(&fw->sq2, coss);
   x = sprintf(buf,"%s %d ", msg, fw->id);
   for (j = SS_ONE_WAY; j != SS_n_states; j += 1) {
      y = sprintf(&buf[x], " %d", fw->state_counts[j]);
      x += y;
      }
   }


void check_was_two_way_timeouts(struct flow_watcher_control *fw,
      uint32_t now_ts) {
   struct source_queue *sq2 = &fw->sq2, *sq = &fw->sq, *tq = &fw->temp;
   uint32_t min_idle_s;
   struct source *sp;
   int keep, terminated;
   int counted = 0, freed = 0;
   min_idle_s = now_ts - WAS_TWO_WAY_TIMEOUT;
#if  SC_DEBUG >= 2
   printf("  =2= check_wtw_timeouts(%d), ts=%u, last_ts=%u, min_idle=%u\n",
      fw->id, now_ts, now_ts, min_idle_s);
#endif
   terminated = 0;
#if SC_DEBUG >= 1
   check_source_chains("--- starting check_was_two_way_timeouts", sq2);
#endif
   for (;;) {  /* sq2 will not be in time order, must check all nodes */
      counted += 1;
      sp = source_shift(sq2);  /* Remove source from head */
      if (sp == NULL) break;  /* End of queue */
      if (sp->state == SS_NEW_ONE_WAY) {  /* Re-appeared! */
         source_push(sq, sp);  /* Move it back into sq */
         continue;
         }
      else if (sp->state == SS_DELETE) keep = 0;
      else if (sp->ts > min_idle_s) {
         source_unshift(tq, sp);  /* Put it back! */
         break;  /* Hasn't been queued long enough; stop checking */
         }
      else {  /* Could be inactive, can we recover it? */
         keep = sp->ts > min_idle_s ||  /* Inactive too long */
	    sp->state != SS_WAS_TWO_WAY;  /* What could this be? */
         }
      if (keep) source_unshift(tq, sp);  /* Add source to head */
      else {    /* Timed-out or SS_DELETE source */
         if (sp->state != SS_DELETE) update_summary_info(sp);
         terminated += 1;
         sp->state = SS_TIMEOUT;
         iat_ht_delete(fw->sh_table, sp);  /* Remove from hash table */
         iat_free_source(sp);
         freed += 1;
         //  check_source_chains("--- after timed out", sq2);
         }
      }
  source_append(sq2, tq);
#if SC_DEBUG >= 2  /* (will print every second!) */
   printf("   =2= %d sources terminated, %d freed, %d counted.  %d WAS_TWO_WAY sources\n",
      terminated, freed, counted, sq2->length);
   fflush(stdout);
#endif
   }

void check_source_timeouts(struct flow_watcher_control *fw,
      uint32_t now_ts) {
   struct source_queue *sq = &fw->sq, *sq2 = &fw->sq2, *tq = &fw->temp;
   uint32_t min_idle_s2, min_idle_s1, last_t_s;
   double av_int;
   struct source *sp;
   int keep, terminated, counted, freed;
#if SC_DEBUG >= 2
   printf("  === check_timeouts(%d), ts=%u\n", fw->id, now_ts);
#endif
   min_idle_s1 = now_ts - ONE_WAY_TIMEOUT;
   min_idle_s2 = now_ts - TWO_WAY_TIMEOUT;
   last_t_s = now_ts;
   terminated = counted = freed = 0;
#if SC_DEBUG >= 2
   check_source_chains("--- starting check_source_timeouts", sq);
#endif
   for (;;) {
      counted += 1;
      sp = source_shift(sq);  /* Remove source from head */
      if (sp == NULL) break;  /* End of queue */
      if (sp->state == SS_ONE_WAY ||
#if HALF_WAY_SOURCES
            sp->state == SS_HALF_WAY ||
#endif
            sp->state == SS_NEW_ONE_WAY)
         keep = 1;
      else if (sp->state == SS_DELETE) keep = 0;
      else if (sp->d.si->last_s > (sp->d.si->timeout == STO_ONE_WAY ?
            min_idle_s1 : min_idle_s2) ) {
         source_unshift(tq, sp);  /* Put it back! */
         break;  /* Hasn't been queued long enough; stop checking */
         }
      else {  /* Could be inactive, can we recover it? */
         if (sp->touched || sp->totp == 1) keep = 1;
         else {
	    av_int = (sp->d.si->last_s - sp->d.si->first_s)/
	       (double)(sp->totp - 1);
	    keep = ((last_t_s - sp->d.si->last_s)  /* Observed idle us */
	       < av_int*STO_MULTIPLIER);  /* Current timeout estimate */
            }
         }
      if (keep) {  /* Don't waste time tesing it until it drifts back
            to the head of the queue.  That means we no longer
            have the queue in (approximnate) LastTime order */
         sp->touched = 0;
         source_unshift(tq, sp);  /* Add source to head */
         }
      else if (sp->state == SS_DELETE) {
         terminated += 1;
         sp->state = SS_TIMEOUT;
         iat_ht_delete(fw->sh_table, sp);  /* Remove from hash table */
         iat_free_source(sp);
         freed += 1;
         }
      else {  /* Timed-out source */
         if (sp->state == SS_TWO_WAY) {  /* Will it reappear as two-way? */
	    sp->state = SS_WAS_TWO_WAY;
	    if (sp->totp > MN_PKTS_FOR_TWO_WAY)  /* Probably two_way */
	       iat_free_source_info(sp);
            }
         else log_msg(user_data, LOG_ERR, 0,
            "Time-out, source state = %d", sp->state);
         source_push(sq2, sp);  /* Move it to timed_out queue */
         /* check_source_chains("--- after timed out", sq); */
         }
      }

  source_append(sq, tq);

#if SC_DEBUG >= 2  /* (will print every second!) */
   printf("   ==== %d sources terminated, %d freed, %d counted.  %d active sources\n",
      terminated, freed, counted, sq->length);
#endif
}

void check_src_nulls(struct source_queue *sq, struct source *sp) {
   if (sp->next == NULL && sp != sq->tail) {
      printf("null sp.next and sp != sp tail ***\n");
      quack(991);
      }
   if (sp->prev == NULL && sp != sq->head) {
      printf("null sp.prev and sp != s head ***\n");
      quack(992);
      }
   }

void *flow_watcher_process(void *arg);

int fw_id = 0;
void start_flow_watcher(struct flow_watcher_control *fw, int ht_size) {
   fw->id = fw_id;  fw_id += 1;
#if STARTUP_DEBUG
   printf("start_flow_watcher(1): ht_size=%d\n", ht_size);  //dd
#endif
   fw->sh_table = iat_ht_create(ht_size);  /* Source hash table */
   if (fw->sh_table == NULL)
      log_msg(user_data, LOG_ERR, 1, "Couldn't create hash table <<<");
   fw->ows_count = 0;  // XXX
   pkt_info_pcq_init(&fw->pq);
   init_source_queue(&fw->sq);
   init_source_queue(&fw->temp);
   init_source_queue(&fw->sq2);
   mutex_lock("sfw", &n_fw_mutex);
   n_fw_running += 1;
   mutex_unlock("sfw", &n_fw_mutex);
#if STARTUP_DEBUG
   printf("start_fw() about to call pthread_create()\n"); fflush(stdout);
#endif
   if (pthread_create(&fw->flow_thread, NULL, flow_watcher_process, fw)) {
      fprintf(stderr, "Error creating flow-watch thread <<<\n");
      exit(41);
      }
#if STARTUP_DEBUG
   printf("leaving start_fw +-+\n"); fflush(stdout);
#endif
   }

#if 0
int check_source_chains(char const *msg, struct source_queue *sq)
{  /* Consistency check for source queue */
   struct source *fsp,*rsp, *l_fsp, *l_rsp;
   int k, nas, rv;

   nas = sq->length;
   fsp = sq->head;  rsp = sq->tail;
   l_fsp = l_rsp = NULL;

   for (rv = 1, k = 0; ; ++k) {  /* Walk forward and reverse chains */
      if (fsp == NULL || rsp == NULL) {  /* Both NULL when done */
         if (fsp != NULL || fsp != rsp) {
	    log_msg(user_data, LOG_WARNING, 0,
               "s_c_c(%s): fsp=%x != rsp=%x, k=%d. nas=%d\n",
	       msg, fsp, rsp, k, nas);
 quack(419);
            rv = 0;
            }
         break;
         }
      if (k > nas+10) {
         log_msg(user_data, LOG_WARNING, 0,
            "s_c_c(%s): loop in chain, k=%d, nas=%d", msg, k, nas);
         fflush(stdout);
 quack(420);
         rv = 0;
         break;
         }
      l_fsp = fsp;  l_rsp = rsp;  /* For gdb debugging */
      fsp = fsp->next;  rsp = rsp->prev;
      }
   printf("s_c_C *** k=%d, nas=%d\n", k, nas);
   if (k != nas) {
      log_msg(user_data, LOG_WARNING, 0,
         "s_c_c(%s): k=%u != nas=%u", msg, k, nas);
      printf("s_c_c(%s): k=%u != nas=%u", msg, k, nas);
 quack(421);
      printf("\n");
      exit(1234);
      rv = 0;
      }
   return rv;
   }
#endif

static void each_time_interval(uint32_t now_ts) {
   /* Called every TIME_INTERVAL */
   int j;  char msg[MXSTRMTXTLEN];
   output_time_record(now_ts);

   for (j = 0; j != n_fw_running; ++j) {
      count_source_states(msg, fwa[j], "#SrcStates:"); 
      log_msg(user_data, LOG_WARNING, -1, msg);
      }

#if SOURCETIMEOUTS  /* For trace file, just write summary at EOF */
   if (now_ts - start_ts < 10) log_msg(user_data, LOG_WARNING, 0,
      "In first 10 s of trace, not writing sum2 file yet");
   else log_msg(user_data, LOG_WARNING, -1,
      "#Record: time to write a sum file!");
#endif

   write_summary(1);
   smee_return_code = SM_RECORD_INTERVAL;
   }

void wait_for_recording_checks(void) {
   for (;;) {  /* Wait for CV_IDLE */
      pthread_mutex_lock(&count_mutex);
      if (CV_IDLE) {
         ct_count -= 1;  /* Set count = CV_RECORDING */
         pthread_mutex_unlock(&count_mutex);
         break;  /* Leave cv unlocked */
         }
      else if (CV_CHECKING) {  /* Wait for timeout checks to finish */
         pthread_mutex_unlock(&count_mutex);  /* Let watchers change count */
         pthread_cond_wait(&count_cv, &count_mutex);
         }
      else log_msg(user_data, LOG_ERR, 1,
         "timeout_checks(): Attempt to Record while CV_RECORDING <<<");
      }
   //s printf("CV_IDLE now\n");  fflush(stdout);
   }

void each_stats_interval(int ts) {
   int pd = pkt_drops(user_data);

   double apc = av_pkt_count == 0 ? 1.0 : av_pkt_count;
   double r_hc_searches = n_hc_searches == 0 ? 1.0 : (double)n_hc_searches;
   double acl = (double)av_cl_count/r_hc_searches;
   int aps = (stats_seconds == 0) ? av_pkt_count :
      (av_pkt_count*10+5)/(stats_seconds*10);
   stat_printf(user_data, "#Stats: %u  aps=%u mps=%u lpk=%u lpp=%.3f"
         "  mpi=%u mso=%u  acl=%.3f msi=%u fi4=%.1f fi6=%.2f"
	 "  nip=%u nfr=%u nts=%u, nlo=%u",
      ts,  aps, mx_pkt_count, pd, (double)pd*100.0/apc,
      mx_active_pkt_infos, mx_active_sources,
      acl, mx_active_source_infos,
      (double)mx_active_v4_flow_infos*100.0/mx_active_source_infos,
      (double)mx_active_v6_flow_infos*100.0/mx_active_source_infos,
      n_not_ip, n_frags, n_too_small, n_no_local_address);

   n_not_ip = n_frags = n_too_small = n_v6_opaque = n_no_local_address = 0;
   stats_seconds = av_pkt_count = mx_pkt_count = mx_active_pkt_infos =
      mx_active_sources = mx_active_source_infos =
      mx_active_v4_flow_infos = mx_active_v6_flow_infos =
      av_cl_count = n_hc_searches = 0;
#if 0
   printf(  /* Test for memory leaks; uses 'unfreed' in iat-mem.h */
   "-- evnt %d, dist %d, v4_fi %d, v6_fi %d, si %d, src %d, pi: %d\n",
      event_unfreed(), distribution_unfreed(), v4_flow_info_unfreed(),
      v6_flow_info_unfreed(), source_info_unfreed(), source_unfreed(),
      pkt_info_unfreed());
#endif
   fflush(stdout);
   }

#if STOP_AFTER
int n_times = STOP_AFTER;
#endif
void each_second(int ts) {
   uint32_t e_type;
   struct pkt_info *event_pp;
   struct flow_watcher_control *fw;
   uint32_t active_pkt_infos,
      active_sources, active_source_infos,
      active_v4_flow_infos, active_v6_flow_infos;
   int j;

   av_pkt_count += pkts_this_second;
   if (pkts_this_second > mx_pkt_count) mx_pkt_count = pkts_this_second;
   pkts_this_second = 0;  stats_seconds += 1;

   last_ts = ts;  /* Save ts for end-of-run */
   set_date_seed(ts);  /* For Conficker p2p test */

   active_pkt_infos = 0;
   for (j = 0; j != n_flow_watchers; ++j) {
      fw = fwa[j];
      active_pkt_infos += pkt_info_pcq_size(&fw->pq);
      }
   if (active_pkt_infos > mx_active_pkt_infos)
      mx_active_pkt_infos = active_pkt_infos;

   active_sources = source_active();
   if (active_sources > mx_active_sources)
      mx_active_sources = active_sources;
   active_source_infos = source_info_active();
   if (active_source_infos > mx_active_source_infos)
      mx_active_source_infos = active_source_infos;

   active_v4_flow_infos = v4_flow_info_active();
   if (active_v4_flow_infos > mx_active_v4_flow_infos)
      mx_active_v4_flow_infos = active_v4_flow_infos;
   active_v6_flow_infos = v6_flow_info_active();
   if (active_v6_flow_infos > mx_active_v6_flow_infos)
      mx_active_v6_flow_infos = active_v6_flow_infos;

   for (;;) {  /* Handle events */
      e_type = check_events(ts);  /* Re-schedule if ep->interval != 0 */
      if (e_type == NO_EVENT) break;
      else switch (e_type) {
      case S_TIME_EVENT:  /* Timeout sources */
         event_pp = get_pkt_info();

         fw_next_st_to_check -= 1;
	 fw = fwa[fw_next_st_to_check];
         if (fw_next_st_to_check == 0)
            fw_next_st_to_check = n_flow_watchers;

         event_pp->event_type = S_TIME_EVENT;
         event_pp->ts = last_ts;
            /* Pass event to flow watcher */
	 pkt_info_pcq_push(&fw->pq, event_pp);
         break;
      case STATS_EVENT:  /* Write #Stats */
#if IATMON 
	 each_stats_interval(ts);
#endif
#if STOP_AFTER
         if (--n_times == 0) request_shutdown = 1;
#endif
         break;
      case TIME_EVENT:  /* Write #Time */
	 each_time_interval(ts);
         break;
         }
      }  /* event handling loop */
   }

int n_tcpks = 0;    //tcpk

void each_pkt(struct flow_watcher_control *fw,
      struct pkt_info *ipp) {
   struct source *slr;
   int new = 1;
   uint32_t hash;

   hash = iat_hash(ipp);
   slr = iat_ht_lookup(fw->sh_table, hash, ipp, &new);
                                /* new => OK_to_insert */
   if (new) {  /* New source, slr == isp */
     // printf("+");  fflush(stdout);  // WWW
      slr->state = SS_ONE_WAY;
      slr->fw_nbr = fw->id;
      slr->d.si->timeout = STO_ONE_WAY;
      slr->version = ipp->version;
      slr->first_fwd = ipp->fwd;
      slr->d.si->tb = slr->d.si->fb = slr->d.si->tp =
         slr->d.si->fp = slr->totp = 0;
      slr->touched = 0;
      slr->d.si->first_s = ipp->at_s;
      slr->d.si->last_report_sec = ipp->ts;
      slr->src_addr = ipp->src_addr;
      slr->d.si->inactive_last_sum = 0;
#if NON_CONF_TEST
      slr->d.si->ab_dest = 0;
#endif
#if ERF_DIRECTION
      slr->d.si->direction = ipp->direction;
#endif
      get_flow_info(slr);
      if (slr->d.si->fi == NULL)
	 log_msg(user_data, LOG_WARNING, 0,
            "each_pkt() couldn't get flow_info");
      slr->d.si->fi->tcp_key = ipp->tcp_key;  /* Save the SYN key */
#if HALF_WAY_SOURCES
      if (slr->version == 4)
         slr->d.si->fi->v.v4.pkts_this_dst = 0;
      else slr->d.si->fi->v.v6.pkts_this_dst = 0;
#endif
      }
   else {  /* Already in table, copy fields from ipp */
      if (slr->state == SS_WAS_TWO_WAY) {
         slr->state = SS_NEW_ONE_WAY;  /* leave it in sq2 for now */
 	 if (slr->d.si == NULL)
            slr->d.si = get_source_info();
         else {
#if OWS_STATS
            slr->d.si->otp = slr->d.si->tp;  slr->d.si->ofp = slr->d.si->fp;
            slr->d.si->ototp = slr->totp;
            slr->d.si->orate = slr->totp == 1 ? 0 : 
               slr->totp/(slr->d.si->last_s - slr->d.si->first_s);
#endif
            slr->d.si->first_s = slr->d.si->last_s;
               /* Time we saw last pkt before timeout */
	    }
         fw->ows_count += 1;
         slr->version = ipp->version;
         slr->first_fwd = ipp->fwd;
         slr->d.si->tb = slr->d.si->fb = slr->d.si->tp =
            slr->d.si->fp = slr->totp = 0;
         slr->d.si->last_report_sec = ipp->ts;
         slr->d.si->timeout = STO_ONE_WAY;
         slr->src_addr = ipp->src_addr;
         slr->d.si->inactive_last_sum = 0;
#  if ERF_DIRECTION
         slr->d.si->direction = ipp->direction;
#  endif
         get_flow_info(slr);
         if (slr->d.si->fi == NULL)
   	    log_msg(user_data, LOG_WARNING, 0,
               "each_pkt() couldn't get flow_info");
         slr->d.si->fi->tcp_key = ipp->tcp_key;  /* Save the SYN key */
         }

#if ERF_DIRECTION  /* Keep track of direction for *all* pkts */
      slr->d.si->direction |= ipp->direction;
#endif
      }
   slr->ts = ipp->ts;
   slr->d.si->last_s = ipp->at_s;

   if (ipp->fwd) {  /* !local -> local, i.e. pkts in to home network */
      slr->d.si->tp += 1;  slr->d.si->tb += ipp->ip_len;
      }
   else {
      slr->d.si->fp += 1;  slr->d.si->fb += ipp->ip_len;
      }
   slr->totp += 1;
   slr->d.si->active_since_last_sum = 1;
   slr->touched = 1;
#if NON_CONF_TEST
   if (ipp->dst_addr.a.a[1] <= 127 && ipp->dst_addr.a.a[3] <= 127)
      slr->d.si->ab_dest += 1;
#endif

   if (slr->state == SS_ONE_WAY ||  /* Not yet SS_TWO_WAY */
          slr->state == SS_NEW_ONE_WAY) {
      if (slr->d.si->fp != 0) {  /* Pkts out from home network -> two-way */
         fw->ows_count -= 1;  // XXX
         slr->state = SS_TWO_WAY;
         slr->d.si->timeout = STO_TWO_WAY;
 	 free_flow_info(slr);  /* Don't need flow info now */
         }
      else {  /* Still one-way, update flow info */ 
	 /* SRI test for Conficker p2p source ... */ 
	 ipp->cfc = 0;
	 if (slr->d.si->fi) {  /* i.e. flow_info != NULL */ 
	    /* Any UDP, any TCP not to port 445 or from port 80 */ 
	    if (ipp->version == 4 && (
	          ipp->proto == PT_UDP || (ipp->proto == PT_TCP && 
		  !(ipp->dst_port == 445 || ipp->src_port == 80)) )) {
	       int i;  result_t res; 
	       portgen(ipp->dst_addr.a.v4, &res, date_seed); 
	       for (i = 0; i < 8; i++) { 
	          if (res.u16[i] == ipp->dst_port) { 
		     ipp->cfc = 1;  /* For updating flow_info */
		     break;  /* Need only match one port! */ 
	             } 
	          } 
	       } 
	    }
         
	 
#if !HALF_WAY_SOURCES 
	 update_flow_info(slr, ipp);
#else
	 int half_flow = update_flow_info(slr, ipp);
         if (slr->state == SS_ONE_WAY && half_flow) { 
	    fw->ows_count -= 1;  // XXX 
	    slr->state = SS_HALF_WAY; 
	    slr->d.si->timeout = STO_ONE_WAY; 
	    free_flow_info(slr);  /* Don't need flow info now */ 
	    } 
#endif   
         } 
      } 
#if HALF_WAY_SOURCES
   else if (slr->state == SS_HALF_WAY) {
      if (slr->d.si->fp != 0) {  /* Pkt out from home -> two-way source */
         slr->state = SS_TWO_WAY;
         slr->d.si->timeout = STO_TWO_WAY;
         }
      }
#endif
   else if (slr->state == SS_DELETE) {
      }
   else if (slr->state == SS_WAS_TWO_WAY) {
      }
   else if (slr->state == SS_NEW_ONE_WAY) {
      }
   else if (slr->state == SS_TWO_WAY) {
      }
   else log_msg(user_data, LOG_ERR, 0,
      "source in state %d <<<<", slr->state);

   if (new) {
      source_push(&fw->sq, slr);
      }
#if SC_DEBUG >= 3
   check_source_chains("+++ end of each_pkt", &fw->sq);
#endif
   }

void shutdown_flow_watchers(void) {
   struct pkt_info *eof_pp;
   int k;
   for (k = 0; k != n_flow_watchers; ++k) {
      //s printf("shutdown_flow_watchers: k=%d\n", k);
      eof_pp = get_pkt_info();
      eof_pp->event_type = END_OF_FILE;
      pkt_info_pcq_push(&fwa[k]->pq, eof_pp);
      }
   }

#if 0
void pa4(struct ip_address *addr) {
   uint8_t *a = addr->a.a;
   printf("%u.%u.%u.%u", a[0],a[1],a[2],a[3]);
   }
void prinfo(struct pkt_info *pp, uint8_t *hdr, uint8_t *thdr) {
   int j;  char abuf[100];
   static int n_times = 50;
   printf("hdr:");
   for (j = 0; j != 32; ++j) printf(" %02x", hdr[j]);
   printf("\n   ver=%d, fwd=%d, ", pp->version, pp->fwd);
   if (pp->version == 4) {
      pa4(&pp->src_addr);  printf(" : ");
      pa4(&pp->dst_addr);
      }
   else {
      v6addr_to_s(abuf, &pp->src_addr);  printf("%s : ", abuf);
      v6addr_to_s(abuf, &pp->dst_addr);  printf("%s", abuf);
      }
   printf(", ttl=%u, ip_len-%d\n", pp->ttl, pp->ip_len);
   if (thdr != NULL) {
      printf("thdr:");
      for (j = 0; j != 40; ++j) printf(" %02x", thdr[j]);  printf("\n    ");
      for (j = 0; j != 40; ++j) printf("  %c",
         isprint((int)thdr[j]) ? thdr[j] : '.');
      printf("\n   proto=%d, ports %u : %u, tcp_key=%08x, flags=%u\n\n",
         pp->proto, pp->src_port, pp->dst_port, pp->tcp_key, pp->tcp_flags);
      }
   n_times -= 1;  if (n_times == 0) exit(123);
   }
#endif

int get_ip_hdr_info(struct pkt_info *pp, 
      uint16_t ethertype, uint8_t *hdr, int hlen) {
   struct ip_address *saddr, *daddr;  struct v6_address temp;
   int sa_local, da_local, fwd;  uint32_t v4_temp;

   if (ethertype == 0x0800) {
      if (hlen < 12+IP4_ADDR_LEN*2)
         return SKEY_NOPEERADDR;  /* Didn't get the peer addresses! */
      if ((ntohs(*(uint16_t *)&hdr[6]) & 0x1FFF) != 0)
	 return SKEY_FRAGPKT;  /* Non-first fragment */

      saddr = &pp->src_addr;  daddr = &pp->dst_addr;
      saddr->a.v4 = *(uint32_t *)&hdr[12];  /* IPv4 source */
      daddr->a.v4 = *(uint32_t *)&hdr[16];  /* IPv4 dest */
      sa_local = addr_is_local(4, saddr);
      da_local = addr_is_local(4, daddr);
      pp->twolocaladdrs = 0;
      if (sa_local && !da_local) fwd = 0;
      else if (!sa_local && da_local) fwd = 1;
      else if (sa_local && da_local) {
         pp->twolocaladdrs = 1;  fwd = 1;
         }
      else return SKEY_NOLOCALADDR;

      if (!fwd) {
	 v4_temp = saddr->a.v4;  saddr->a.v4 = daddr->a.v4;
         daddr->a.v4 = v4_temp;
         }
      pp->version = 4;  pp->ttl = hdr[8];  pp->fwd = fwd;
      pp->ip_len = ntohs(*(uint16_t *)&hdr[2]);
      }
   else {  /* IPv6 */
      if (hlen < 8+IP6_ADDR_LEN*2)
	 return SKEY_NOPEERADDR;  /* Didn't get the peer addresses! */
         // r = SKEY_NOPEERADDR;

      saddr = &pp->src_addr;  daddr = &pp->dst_addr;
      memcpy(saddr->a.a, &hdr[8], IP6_ADDR_LEN);  /* IPv6 source */
      memcpy(daddr->a.a, &hdr[24],IP6_ADDR_LEN);  /* IPv6 dest */
      sa_local = addr_is_local(6, saddr);
      da_local = addr_is_local(6, daddr);
      if (sa_local && !da_local) fwd = 0;
      else if (!sa_local && da_local) fwd = 1;
      else if (sa_local && da_local) {
         pp->twolocaladdrs = 1;  fwd = 1;
         }
      else return SKEY_NOLOCALADDR;

      if (!fwd) {
         memcpy(&temp, saddr, sizeof(struct v6_address));
         memcpy(saddr, daddr, sizeof(struct v6_address));
         memcpy(daddr, &temp, sizeof(struct v6_address));
         }

      pp->version = 6;  pp->ttl = hdr[7];  pp->fwd = fwd;
      pp->ip_len = 40 + ntohs(*(uint16_t *)&hdr[4]);
         /* Header + payload (includes extension headers) */
      }

   return SKEY_OK;
   }

static char const *bT_DHT_val = "d1:ad2:id20:";  /* 12 bytes 0..11 */
static char const *uT_proto_val =  /* 16 bytes 12..27 */
   "\x7f\xff\xff\xff\xab\x02\x04\x00\x01\x00\x00\x00\x08\x00\x00\x00";

/* 'tcp_key' layout, from a SYN packet - bits (0 at the left):
    0.. 3  Window scale (bottom 4 bits)
        4  SACK permitted
        5  Timestamp
    6..15  MSS - 600 (to fit into 10 bits)
   16..31  Opening window size  */

uint32_t tcp_key(uint8_t *hdr, int hl) { 
   uint32_t val;  int x;

   if (hl < 16) return 0;
   if ((hdr[13] & 0x02) == 0)  /* SYN flag not present */
      return 0;
   val = ntohs(*(uint16_t *)&hdr[14]);  /* Window size */

   if ((hdr[12] >> 4) == 5) return val;  /* No options */

   x = 20;
   for (;;) { 
      switch (hdr[x]) { 
      case 0:  /* End of option list */ 
         return val; 
      case 1:  /* No-op */ 
         x += 1; 
         break;
      case 2:  /* MSS */ 
         val |= (ntohs(*(uint16_t *)&hdr[x+2])-600) << 16;  /* 10 bits */
         break;
      case 3:  /* Window scale */ 
         val |= ntohs(*(uint16_t *)&hdr[x+2]) << 28;  /* Top 4 bits */
         break;
      case 4:  /* SACK permitted */
         val |= 0x08000;
         break;
      case 8:  /* Timestamp */
         val |= 0x04000000;
         break;
         }
      if (x+1 >= hl || hdr[x+1] == 0) break; 
      x += hdr[x+1]; 
      if (x >= hl) break; 
      } 
   return val; 
   } 

#define test_ut \
   pp->uTorrent = \
      (rem >= 8+0+12 && \
         (memcmp(&thdr[8+0], bT_DHT_val, 12) == 0)) || \
      (rem >= 8+12+16 && \
       (memcmp(&thdr[8+12], uT_proto_val, 16) == 0));

uint32_t nfw[4] = {0, 0, 0, 0};

int iat_process_packet(libtrace_packet_t *packet, int action_req) {
   struct event *ep;
   double sec;
   uint16_t ethertype;   uint32_t brem;  libtrace_ip_t *ip;
   int ts, key_code, fw_nbr;
   struct pkt_info *pp;
   uint8_t *thdr;  uint8_t proto;  uint32_t rem;
   uint16_t sport = 0, dport = 0;

   if ((action_req == SM_PACKET || action_req == SM_DUMMY) 
         && packet == NULL) {  /* EOF */
      shutdown_flow_watchers();  /* Send EOF to flow_watchers */
      write_summary(2);
      return SM_OK;
      }
   else if(action_req == SM_RECORD_REQ) {
      each_stats_interval(last_ts);
      return SM_OK;
      }

   if (request_shutdown) {
      shutdown_flow_watchers();  /* Send EOF to flow_watchers */
      write_summary(3);
      return SM_STOP_REQUEST;
      }

   smee_return_code = SM_OK;
   pkts_this_second += 1;  pkts_from_trace += 1;
   sec = trace_get_seconds(packet);
   if (start_ts == 0) {
      last_timerec_sec = last_ts = start_ts = sec;  /* Coerce to int */
      start_tt = start_ts;
      r_start_ts = sec;  /* Seconds part */

      ep = get_iat_event(S_TIME_EVENT, 1);    /* Every 1s */ 
      schedule_event(ep, start_ts+3);  /* First time 3s from now */
      ep = get_iat_event(STATS_EVENT, STATS_RECORDING_INTERVAL);
      schedule_event(ep, start_ts+4);
      ep = get_iat_event(TIME_EVENT, time_rec_interval);
      ts = (start_ts+time_rec_interval-1)/
         time_rec_interval*time_rec_interval;
      if (ts < (int)sec + 30)  /* Don't record a summary in first 30 s */
         ts += time_rec_interval;
      schedule_event(ep, ts);

      output_fdf_hdr();  /* Output .fdf header record(s) */

      set_date_seed(start_ts);  /* For Conficker p2p test */
      }
   ip = trace_get_layer3(packet, &ethertype, &brem);
   if (!ip || (ethertype != 0x0800 && ethertype != 0x86dd)) {
      __sync_fetch_and_add(&n_not_ip, 1);
      __sync_fetch_and_add(&t_not_ip, 1);
      }
   else {
      pp = get_pkt_info();
      if (pp == NULL) quack(99);

      pp->at_s = sec;
      ts = sec;  /* Coerce to int */
      if (ts > last_ts) each_second(ts);

      key_code = get_ip_hdr_info(pp, ethertype, (uint8_t *)ip, brem);
      if (key_code != SKEY_OK) {  /* Couldn't get packet info */
         switch (key_code) {
         case SKEY_NOPEERADDR:
            __sync_fetch_and_add(&n_too_small, 1);
	    __sync_fetch_and_add(&t_too_small, 1);
            break;
         case SKEY_FRAGPKT:
     	     __sync_fetch_and_add(&n_frags, 1);
     	     __sync_fetch_and_add(&t_frags, 1);
            break;
         case SKEY_NOLOCALADDR:
	    __sync_fetch_and_add(&n_no_local_address, 1);
	    __sync_fetch_and_add(&t_no_local_address, 1);
            break;
         case SKEY_V6OPAQUE:
	    __sync_fetch_and_add(&n_v6_opaque, 1);
	    __sync_fetch_and_add(&t_v6_opaque, 1);
            break;
         default:
	    printf("code=%d ", key_code);  //@
 	    log_msg(user_data, LOG_ERR, 0,  /* IP ver wrong for ethertype */
	       "packet_watcher: bad key_code %d !!!", key_code);
            break;
            }
	 }
      else {  /* key_code == SKEY_OK */
	 if (pp->twolocaladdrs) 
            __sync_fetch_and_add(&t_twolocaladdrs, 1);

         thdr = trace_get_transport(packet, &proto, &rem);
            /* Get transport fields */
         pp->tcp_key = 0;  pp->tcp_flags = pp->uTorrent = 0;
         switch (pp->proto = proto) {
         case PT_TCP:
#if HALF_WAY_SOURCES
            pp->tcp_seq = ntohl(*(uint32_t *)&thdr[4]);
            pp->tcp_ack = ntohl(*(uint32_t *)&thdr[8]);
      	    /* We only want to see whether seq or ack is increasing,
               so we don't need to check the ACK flag */
#endif
            pp->tcp_flags = rem >= 14 ? thdr[13] : 128;
         case PT_UDP:
            if (rem < 4)
               key_code = SKEY_NOTRANSADDR;  /* Didn't get IP ports! */
            else {
               sport = ntohs(*(uint16_t *)&thdr[0]);  /* Source port */
               dport = ntohs(*(uint16_t *)&thdr[2]);  /* Dest port */
               }

            if (pp->fwd) {
               pp->src_port = sport;  pp->dst_port = dport;
               }
            else {
               pp->src_port = dport;  pp->dst_port = sport;
               }
            break;
         case PT_ICMP:
            pp->src_port = 0;    /* Type field */
            pp->dst_port = ntohs(*(uint16_t *)&thdr[0]);
            break;               /* Type|Code */
         default:
            pp->src_port = pp->dst_port = 0;
            break;
            }

         if (pp->proto == PT_TCP) {
            pp->tcp_key = tcp_key(thdr, rem);
            }
         else if (pp->proto == PT_UDP) {
            test_ut;
            }

         if (key_code == SKEY_OK) {
            fw_nbr = (n_flow_watchers == 1 ? 0 :
               (pp->version == 4 ? pp->src_addr.a.a[IP4_ADDR_LEN-2] :
               pp->src_addr.a.a[IP6_ADDR_LEN-2]) )
   	       % n_flow_watchers;
            nfw[fw_nbr] += 1;
            pp->event_type = NO_EVENT;
            pp->ts = ts;
            pp->payload_len = trace_get_payload_length(packet);
#if ERF_DIRECTION
 	    pp->direction = trace_get_direction(packet)+1;
	       /* 0 => portA, 1 => portB */
#endif
            /* Pass pkt_info to selected flow watcher */
   	    pkt_info_pcq_push(&fwa[fw_nbr]->pq, pp);
            pp = NULL;
	    }
         else if (key_code == SKEY_NOTRANSADDR) {
	    __sync_fetch_and_add(&n_too_small, 1);
	    __sync_fetch_and_add(&t_too_small, 1);
	    }
	 else {
	    printf("code=%d ", key_code);  //@
 	    log_msg(user_data, LOG_ERR, 0,  /* IP ver wrong for ethertype */
	       "packet_watcher: bad key_code %d !!!", key_code);
	    }
   	 }
      if (pp != NULL) free_pkt_info(pp);
      }
   return smee_return_code;
   }

void *flow_watcher_process(void *arg) {
   struct flow_watcher_control *fw = arg;
   struct pkt_info *ipp;
   int shutdown_now, rake_reqd, j;

#if STARTUP_DEBUG
   printf("starting flow_watcher_process() +-+\n"); fflush(stdout); 
#endif
   for (;;) {
      ipp = pkt_info_pcq_shift(&fw->pq);  /* Wait for a pkt_info */
      if (ipp->event_type == END_OF_FILE) {
	 //s printf("flow_watcher(%d): EOF\n", fw->id);
         break;
         }
      else switch (ipp->event_type) {
      case S_TIME_EVENT:
        rake_reqd = (source_allowed()-source_active()) < MN_FREE_SOURCES;
        if (SOURCETIMEOUTS || rake_reqd) {
            mutex_lock("recording", &count_mutex);
	    if (CV_RECORDING)  /* Handling #Record: don't try to rake */
	       mutex_unlock("recording", &count_mutex);
	    else {
  	       ct_count += 1;  /* About to run check_source_timeouts() */
               mutex_unlock("recording", &count_mutex);
	       if (rake_reqd)
                  j = rake_idle_sources(fw, ipp->ts);
               else if (SOURCETIMEOUTS) {
		  check_source_timeouts(fw, ipp->ts);
                  check_was_two_way_timeouts(fw, ipp->ts);
	          }
    	       pthread_mutex_lock(&count_mutex);
	       ct_count -= 1;  /* check_source_timeouts() finished */
	       pthread_mutex_unlock(&count_mutex);
 	       pthread_cond_signal(&count_cv);  /* Let Record: know! */
	       }
	    }
	 break;
      default:
	 __sync_fetch_and_add(&pkts_at_flow_watchers, 1);
	 each_pkt(fw, ipp);  /* pcq_push will free the node */
	 break;
         }
      }  /* Loop finishes on interrupt or end of trace file */

   mutex_lock("fwp", &n_fw_mutex);
   n_fw_running -= 1;
   shutdown_now = n_fw_running == 0;
   mutex_unlock("fwp", &n_fw_mutex); 
   //s printf("q_size=%d, fw=%d, shutdown_now=%d\n",
   //s pkt_info_pcq_size(&fw->pq), fw->id, shutdown_now);
   fflush(stdout);

   if (shutdown_now) {
     //s printf("$$$ shutting down ...\n");
      struct flow_watcher_control *fw;
      char buf[120];
      for (j = 0; j != n_flow_watchers; ++j) {
 	 fw = fwa[j];
         count_source_states(buf, fw, "#SrcStates:"); 
         printf("%s, q_size=%d, mx=%d\n", buf, 
	    pkt_info_pcq_size(&fw->pq), pkt_info_mx_pcq_size(&fw->pq));
         }
      printf("nfw[] = %u, %u, %u, %u\n", nfw[0], nfw[1], nfw[2], nfw[3]);
      }
   return NULL;  /* Keep compiler happy */
   }
