/* 1154, Wed 23 May 12 (PDT)
   2255, Fri 23 Dec 11 (NZDT)  v2.1 source layouts
   1541, Thu 17 Mar 11 (PDT)
   1628, Sat 17 Dec 10 (NZDT) 
   0927, Mon 30 Aug 10 (NZST)
   1550, Tue 27 Jul 10 (CEST)
   1253, Wed 19 May 10 (NZST)
   1955, Thu 22 Apr 10 (PDT)
   1445, Wed  5 Dec 07 (NZDT)

   iat.h:  Globals for OneWayTraffic Monitor

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2013 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/* #define IATMON x  // 1 if we're building the iatmon Ruby extension
                         set by extconf.rb when it builds the Makefile */
#ifndef __IATMON_H
#define __IATMON_H

#include "config.h"

#include <sys/types.h>
#include <stdint.h>
#include <sys/stat.h>

#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include <stdlib.h>
#include <inttypes.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <sys/resource.h>
#include <time.h>
#include <syslog.h>
#include <unistd.h>

#include <pthread.h>
/* OSX uses pthread_yield_np, i made autoconf detect this */
#define pthread_yield PTHREAD_YIELD_FUNC

#include "semaphore.h"

#include "libtrace.h"

#if IATMON
# include "../iat-conf.h"  /* Building iatmon */
#else
# include "iat-conf.h"  /* Building libsmee */
#endif

/* thor:      DFMXFLOWWATCHERS 1, SOURCETIMEOUTS 0
   ua-trace:  DFMXFLOWWATCHERS 1, SOURCETIMEOUTS 1
   ua-live:   DFMXFLOWWATCHERS 4, SOURCETIMEOUTS 1

   Fri, 21 May 10 (NZST):  These are set by ./configure in iat_conf.h
      ./configure --enable-two-way --enable-half-way --with-watchers=4 */

// #define DFMXFLOWWATCHERS   1  /* Number of flow watcher threads */
//                              /*   (4 has more overhead on odin) */
// #define HALF_WAY_SOURCES   0  /* Watch 'half-way' sources;
//      increasing TCP seq/ack => we're not seeing the return path */
// #define SOURCETIMEOUTS     0  /* Time out inactive sources */

#if SOURCETIMEOUTS
#  define ERF_DIRECTION      1  /* 1 to count interface field from DAG card */
#  define OWS_STATS          0
                /* Write stats info for WAS_TWO_WAY and NEW_ONE_WAY sources */
#else
#  define ERF_DIRECTION      0
#  define OWS_STATS          0
#endif

#define NON_CONF_TEST        0  /* Look for Conficker A/B sources */

#include "iat-mem.h"
#include "iat-pc-queue.h"  /* Lock-free producer/consumer queue */
#include "iat-sm-queue.h"  /* Semaphore-managed producer/consumer queue */
#include "iat-12-queue.h"  /* owtmon 1-way and 2-way array-like queues */

#include "iat-smee.h"  /* (smee needs NON_CONF_TEST) */


#define HALF_ONE_WAY_PKTS  10  /* If we see this many pkts with increasing
				  TCP seq or ack, it's a two-way source,
				  but we're only seeing one direction of it */

#define MKSTATSCOUNTS      0  /* To build/collect interval stats */
#define MKDESTCOUNTS       0  /* To build/collect dst_addr/24block stats */
#define NDESTBINS        256  /* 256 /24 blocks in telescope space */

#define CHECKPKTQUEUE      0  /* Debugging defines */
#define STOP_AFTER         0  /* stop_meter() after this many #Stats calls */
                              /*   0 to only stop at EOF */
#define SC_DEBUG  0  /* Source chain checks:
         0 = none
         1 = start of cto() [check_source_timeouts()]
         2 = start cto() + print cto() stats
         3 = start & end of cto() + end of each_pkt() */
#define STARTUP_DEBUG      0  /* 1 to print 'got to here' lines */

#define PRODUCTION         1  /* 0 to display statistics < every minute */
#if PRODUCTION
#  define STATS_RECORDING_INTERVAL  60  /* 1m */
#else
#  define STATS_RECORDING_INTERVAL  20  /* 20s */
#endif
#define STATS_INTERVALS_PER_HOUR  3600/STATS_RECORDING_INTERVAL
/* #Time recording interval is set by -c in iat.init method */

                               /* Default sizes */
#define DFMXOPQENTRIES  25000  /* Size of output queue */
#define DFMXSOURCES    250000  /* Nbr of sources */
#define DFMXEVENTS          5  /* Nbr of events */
#define DFMXPWQUEUESZ    1000  /* Max length of packet watcher input queue */

#define MIN_HT_SIZE   2000000  /* Don't want long hash chains! */

#define IP4_ADDR_LEN      4  /* IP address sizes */
#define IP6_ADDR_LEN     16

#define PT_ICMP        1  /* IP protocol types */
#define PT_TCP         6
#define PT_UDP        17
#define PT_SCTP      132
                          /* IPv6 protocol types */
#define PT_6HOP        0  /* Hop-by-hop options */
#define PT_6ROUT      43  /* Routing (Type 0) */
#define PT_6FRAG      44  /* Fragment */
#define PT_6ESP       50  /* Encapsulating Security Payload (ESP) RFC 2406 */
#define PT_6AH        51  /* Authentication (AH) RFC 2402 */
#define PT_6ICMP      58  /* ICMPv6 */
#define PT_6NONH      59  /* No next header */
#define PT_6DEST      60  /* Destination options */
#define PT_6MOBILE   135  /* IPv6 Mobility Header */ 


/* Well-known port numbers */
#define PN_SSH        22  /* ssh */
#define PN_TELNET     23  /* telnet */
#define PN_DNS        53  /* Domain Name System */
#define PN_US_DS     445  /* Microsoft-DS SMB file sharing */

#define ICMP_DST_UNREACHABLE   3  /* ICMP Types */
#define ICMP_TTL_EXCEEDED      11
#define ICMP6_DEST_UNREACHABLE  1  /* ICMP6 Types */
#define ICMP6_TTL_EXCEEDED      3

#define SKEY_OK           0  /* s_key return codes */
#define SKEY_NOSPACE      1
#define SKEY_NOTIP        2
#define SKEY_NOPEERADDR   3
#define SKEY_FRAGPKT      4
#define SKEY_NOTRANSADDR  5
#define SKEY_BADIPHDR     6
#define SKEY_V6SMALLSNAP  7
#define SKEY_V6OPAQUE     8
#define SKEY_NOLOCALADDR  9

char *fmt_time(int ti);
extern void (*log_msg)(void *user_data, int priority, int die, char const *fmt, ...);
extern int (*stat_printf)(void *user_data, const char *fmt, ...);
extern int (*sum_printf)(void *user_data, const char *fmt, ...);
extern int (*sources_printf)(void *user_data, const char *fmt, ...);
extern uint64_t (*pkt_drops)(void *user_data);

struct iat_ht {
   int table_size;  /* Max entries, used as hashmod */
   void **sfht;  /* Actual hash table */
   };

#define SS_FREE          0  /* Source states */
#define SS_ONE_WAY       1
#define SS_TWO_WAY       2  /* Don't need to save pkts */
#define SS_HALF_WAY      3
#define SS_WAS_TWO_WAY   4  /* Two-way, timed out */
#define SS_NEW_ONE_WAY   5  /* Reappeared as one-way */
#define SS_DELETE        6
#define SS_TIMEOUT       7
#define SS_n_states      8

extern struct ip_address *la;
extern int n_local_addrs;
extern int local_v6;  /* 1 if we have a v6 local address */

                          /* Parameters for source statistics */
#define MIN_LIFETIME 1.0  /* seconds */
extern int mx_life;

extern int save_distributions;  /* Non-zero to print source distribs */
#define LOWER_IAT  0.15  /* s  IAT Distribution parameters */
#define UPPER_IAT  600.0
#define MXBUCKETS  120  /* Values below computed by iat-rb/dist-bins.rb */
#define C16  65
#define  C8  55
#define FIRST_8BIT_BIN  66

struct distribution {
   double M;   /* Range, for transform() */
   double step;  /* For computing bin edges */
   double last_y;  /* For computing IATs */
   double LowerLim, UpperLim;
   uint32_t total_count, bin0_count;
   uint16_t counts16[C16];
   uint8_t counts8[C8];  /* Top bin is oflo bucket */
   uint8_t Transform, Buckets;  /* Distrib parameters */
   };

#  define DS_NULL       0  /* Distribution transform type values */
#  define DS_LIN        1  /* Linear */
#  define DS_LOG        2  /* Logarithmic */
#  define DS_LIN_DIF    3  /* Lin + take diff between bump_dist() calls */
#  define DS_LOG_DIF    4  /* Log + take diff between bump_dist() calls */

iat_mem_declare_globals(distribution);

#define MX_N_UINT32  10
#define MX_N_UINT16  10
#define MX_N_UINT8   10
#define V4_SET_SIZE   9  /* 19 Oct 11, allow for prev_dest */
#define V6_SET_SIZE   5

#define topn_t(name, sz, type) \
   struct topn_##name { \
      uint32_t nv; \
      uint32_t counts[sz];  type values[sz]; \
      };

topn_t(uint32, MX_N_UINT32, uint32_t);
topn_t(uint16, MX_N_UINT16, uint16_t);
topn_t(uint8, MX_N_UINT8, uint8_t);
topn_t(dst_addrs4, V4_SET_SIZE, struct v4_address);
topn_t(dst_addrs6, V6_SET_SIZE, struct v6_address);

struct v4_flow_info {
   struct distribution *d;
   uint32_t cfc_count, uT_count, tcp_key;
   struct topn_uint16 tn_tcp, tn_udp, tn_src_port, tn_iplen;
   struct topn_uint8 tn_flags, tn_proto, tn_ttl;
   struct topn_dst_addrs4 tn_dst_addrs;
#if HALF_WAY_SOURCES
   struct v4_address prev_dst;
   uint32_t pkts_this_dst, prev_seq, prev_ack;
#endif
   };
iat_mem_declare_globals(v4_flow_info);

struct v6_flow_info {
   struct distribution *d;
   uint32_t cfc_count, uT_count, tcp_key;
   struct topn_uint16 tn_tcp, tn_udp, tn_src_port, tn_iplen;
   struct topn_uint8 tn_flags, tn_proto, tn_ttl;
   struct topn_dst_addrs6 tn_dst_addrs;
#if HALF_WAY_SOURCES
   struct v6_address prev_dst;
   uint32_t pkts_this_dst, prev_seq, prev_ack;
#endif
   };
iat_mem_declare_globals(v6_flow_info);

struct flow_info {
   struct distribution *d;
   uint32_t cfc_count, uT_count, tcp_key;
   struct topn_uint16 tn_tcp, tn_udp, tn_src_port, tn_iplen;
   struct topn_uint8 tn_flags, tn_proto, tn_ttl;
   union {
      struct {
         struct topn_dst_addrs4 tn_dst_addrs;
#if HALF_WAY_SOURCES
         struct v4_address prev_dst;
         uint32_t pkts_this_dst, prev_seq, prev_ack;
#endif
         } v4;
      struct {
         struct topn_dst_addrs6 tn_dst_addrs;
#if HALF_WAY_SOURCES
         struct v6_address prev_dst;
         uint32_t pkts_this_dst, prev_seq, prev_ack;
#endif
         } v6;
      } v;
   };

struct pkt_info {  /* Data for individual packet (or event) ... */
   struct pkt_info *next;  /* Free queue */
   uint16_t ip_len, src_port, dst_port,
      payload_len;  /* Payload length */
   uint8_t fwd,    /* 1 = in to home network */
      event_type,   /* pkt event (EVENT values, 0 to just count pkt) */
      version, proto,
      twolocaladdrs, tcp_flags, ttl, res1,
      uTorrent, cfc;
#if ERF_DIRECTION
   uint8_t direction, res2;
#else
  uint8_t res2, res3;
#endif
   uint32_t tcp_key;  /* mss, window */
#if HALF_WAY_SOURCES
   uint32_t tcp_seq, tcp_ack;
#endif
   uint32_t ts;
   double at_s;  /* Packet arrival time (s) */
   struct ip_address src_addr, dst_addr;  /* For 'this packet' */
   };

iat_mem_declare_globals(pkt_info);
iat_pcq_declare_globals(pkt_info);  /* pkt_info pc queue */

struct source {  /* Hash table fields, key is (src addr) */
   struct source *next_hc;    /* For utht(), must be first */
   struct source *next, *prev;  /* For source queue(s) */
   uint8_t version, state,
      fw_nbr,      /* flow_watcher nbr */
      first_fwd,   /* Remembers fwd value for first packet */
      touched,      /* Saw a new pkt since last sq check */
      res1, res2, res3;
   uint32_t totp;  /* tp + fp */
   uint32_t ts;    /* Time of last activity */
   union {
      /* No extra data            WAS_TWO_WAY */
      struct source_info *si;  /* ONE_WAY, TWO__WAY */
      } d;
   struct ip_address src_addr;  /* May be IPv4 or IPv6 */
   };

iat_mem_declare_globals(source);
iat_queue_declare_globals(source);

struct source_info {  /* Data for a source we're watching */
   uint8_t
      timeout,    /* In seconds for this source */
      cfc,        /* Conficker C pkts seen */
      uTorrent,   /* uTorrent packets seen */
#if ERF_DIRECTION
      direction;
#else
      res1;
#endif

   uint8_t  /* Variables used by the Ruby outer block ... */
      active_since_last_sum,
      inactive_last_sum,
      res4, res5;

   uint32_t last_report_sec;  /* ts when last source report was queued */
#if NON_CONF_TEST
   uint32_t ab_dest;  /* Dest address in conficker A/b range */
#endif
#if HALF_WAY_SOURCES
   uint32_t tcp_seq, tcp_ack;
#endif

  /* Summary data for the source ... */
   double first_s, last_s;  /* Times for first and last packets */
   uint64_t tb, fb;         /* To/From byte counts */
   uint32_t tp, fp;         /* To/From packet counts */
#if OWS_STATS
   double orate;
   uint32_t otp, ofp, ototp;  /* Counts from original TWO_WAY state */
#endif
    struct flow_info *fi;
#if MKSTATSCOUNTS 
   uint16_t last_active_interval;
#endif
   };

iat_mem_declare_globals(source_info);

extern int probe_port, src_port;  /* analyse_flow() results */
extern int flags_mode, keys_mode, iplen_mode;
extern int probe_port_valid,   /* (other than src_type) */
   too_few_pkts,      /* < MinPkts */
  protocol, ttl_mode;

extern double b0pc, modeiat, skew;  /* compute_distrib_stats() results */
extern int nz_runs;

extern void *user_data;  /* From Corsaro */

void init_distrib(struct distribution *d,
   double lower, double upper, int bins, int transform);
void bump_dist(  /* Add point y into distrib d */
   struct distribution *d, double y);
void accum_dist(  /* Add v to point y of distrib d */
   struct distribution *d, double y, uint32_t v);

void write_distrib_info(FILE *f, struct source *sp, struct distribution *d);
void write_summary(int which);
int compute_distrib_stats(struct source *sp);

#define MX_EXTRA_BLOCKS     2  /* source, flow_info and distribution */
#define MN_FREE_SOURCES     200000
#define MN_SOURCES_TO_FREE  250000

#if MKSTATSCOUNTS
extern uint32_t  /* Per-interval stats arrays for each source type .. */
//x   **pkts_seen_per_stats_interval, *pkts_seen_this_interval,
   **active_sources_per_stats_interval, *active_sources_this_interval,
   **unique_hosts_per_stats_interval, *unique_hosts_this_interval;
extern uint32_t stats_interval_nbr;
#endif
#if MKDESTCOUNTS
extern uint32_t **dest_addrs_per_source_type;
#define src_addr_bin(a)  ((ntohl(a) >> 24) & 0x000000FF)  /* 1st byte */
extern uint32_t (*dest_addr_bin)(uint32_t a);
#endif

#define MX_ONE_WAY_TIMEOUTS_PER_CHECK  20000  /* 6 Aug 10 */
   /* Limit demand on opq_empty!  23 Jun 10 */

#define TCP_SOURCE_TIMEOUT     2  /* 2s (FIN_WAIT) */

#define TOO_MANY_TIMEOUT     120  /* 'Flood' source time to be "idle" */
#define MN_PKTS_FOR_DISCARD    2  /* Recover sources with more pkts */

#define MN_PKTS_FOR_TWO_WAY    4  /* Timed-out 2-way sources with more pkts
				     seem OK, don't need to keep source_info */

#define TWO_WAY_TIMEOUT        3  /*  5s */
#define ONE_WAY_TIMEOUT        5  /* 10s */
#define WAS_TWO_WAY_TIMEOUT  300 // 120 // 180  // 300
#define STO_MULTIPLIER        20 // 10

#define STO_ONE_WAY            1  /* Timeout kinds for sources .. */
#define STO_TWO_WAY            2
#define STO_WAS_TWO_WAY        3

extern int mx_sources, n_source_types, pkts_to_record, min_pkts_to_classify;

extern uint32_t n_unanalysed_sources, n_unanalysed_pkts;
extern uint32_t    /* Stats for unanalysed sources */
   ua_pkts[MN_PKTS_FOR_DISCARD],  /* Nbr of packets */
   ua_src_addr[256],  /* Source addresses */
   ua_dst_addr[256],  /* Dest addresses */
   ua_ttl[256],       /* TTLs */
   ua_proto[256],     /* Protocols */
   ua_gt1prot;        /* More than one proto seen */

extern int time_rec_interval, intervals_this_sum_file;

extern int mx_active_pkt_infos, mx_active_sources, mx_active_source_infos,
   mx_active_v4_flow_infos, mx_active_v6_flow_infos,
   av_cl_count, n_hc_searches;

extern uint64_t      /* Packets counted by various threads; reset */
   pkts_from_trace,  /*  after outer block writes summary file */
   t_not_ip, t_frags, t_too_small, t_no_local_address, t_v6_opaque,
   t_twolocaladdrs, pkts_at_flow_watchers, pkts_to_ob;

extern int     /* Packets discarded by flow_watcher; reset
                       every TIME_INTERVAL (i.e. #Stats log_msg) */
   n_not_ip, n_frags, n_too_small, n_no_local_address, n_v6_opaque,
   av_pkt_count, mx_pkt_count, stats_seconds;

extern int pkts_this_second;  /* One_second packet counts */

extern uint64_t  /* Overall source summary info */
   v4_one_way_bytes,  v4_one_way_pkts,  v4_one_way_sources,
   v6_one_way_bytes,  v6_one_way_pkts,  v6_one_way_sources,
   v4_two_way_bytes,  v4_two_way_pkts,  v4_two_way_sources,
   v6_two_way_bytes,  v6_two_way_pkts,  v6_two_way_sources,
   v4_half_way_bytes, v4_half_way_pkts, v4_half_way_sources,
   v6_half_way_bytes, v6_half_way_pkts, v6_half_way_sources;
#if ERF_DIRECTION
extern uint64_t
   one_way_sources_1, one_way_sources_2, one_way_sources_3,
   two_way_sources_1, two_way_sources_2, two_way_sources_3, 
   half_way_sources_1, half_way_sources_2, half_way_sources_3;
#endif

extern double r_start_ts;  /* Seconds part of first-packet */
extern time_t start_tt;
extern int start_ts,
   last_ts;           /*    and last-packet timestamps */

#define NO_EVENT       0  /* Event types */
#define S_TIME_EVENT   1  /* Check source timeouts */
#define STATS_EVENT    2  /* Write interface stats */
#define TIME_EVENT     3  /* Write #Time record */
#define END_OF_FILE    4  /* End of trace file */

struct event {
   int t, type, interval;  /* Interval in seconds */
   struct event *next;
   };
extern struct event event_q;  /* Event queue, dummy first member */
   /* Maintained by get_iat_event(), schedule_event(); check_events() */
iat_mem_declare_globals(event);

/* mutexes for data structures shared between threads .. */
extern pthread_mutex_t 
   n_fw_mutex,         /* n_fw_running */
   count_mutex;        /* lock for count/count_cv */

extern  pthread_cond_t count_cv;

extern int ct_count;  /* Nbr of check_timeouts() running */
#define CV_CHECKING   (ct_count > 0)
#define CV_IDLE       (ct_count == 0)
#define CV_RECORDING  (ct_count < 0)


/* Globals set by iat_open() ... */

extern const char *iat_trace_name;
extern const char *iat_meter_loc;   /* SAN, AKL, ... */
extern int mx_life;  /* Upper limit of lifetime distributions */
extern int first_ts, last_ts;  /* For current recording interval */

struct flow_watcher_control {
   iat_pcq_declare_space(pq, pkt_info);
   struct iat_ht *sh_table;  /* Source (hash) table */
   iat_queue_declare_space(sq, source);  /* For 'normal' sources */
   iat_queue_declare_space(temp, source);
   iat_queue_declare_space(sq2, source);  /* Timed-out sources */
   pthread_t flow_thread;
   int id;
   int ows_count;  // XXX 
   int state_counts[SS_n_states];  // XXX
   };

iat_mem_declare_globals(flow_watcher_control);
extern struct flow_watcher_control **fwa;  /* Flow_watcher aaray */
extern int n_flow_watchers, fw_next_st_to_check;

extern int n_fw_running;  /* Nbr of flow watchers running */

extern char *version;

struct iat_usage {
  double tod, tuser, tsystem, mxrss;
};

/* Functions in iat_watcher.c */

void quack(int nnn);
int sv4p_bad(struct source *sp);

char *iat_file_header(void);

void update_interface_stats(uint32_t not_ts);
void each_time(uint32_t now_ts);
void check_was_two_way_timeouts(
   struct flow_watcher_control *fw, uint32_t now_ts);
int rake_idle_sources(
   struct flow_watcher_control *fw, uint32_t now_ts);
void check_sources_timeouts(
   struct flow_watcher_control *fw, uint32_t now_ts);
void output_active_sources(struct source_queue *sq, uint32_t now_ts);

void each_second(int ts);
void each_stats_interval(int ts);
extern int request_shutdown,  /* True to stop iatmon */
   smee_return_code;

void each_pkt(struct flow_watcher_control *fw, struct pkt_info *ipp);

extern int errno;

void start_flow_watcher(struct flow_watcher_control *fw, int ht_size);
void wait_for_recording_checks(void);

/* Functions in iat_support.c */

struct event *get_iat_event(int t, int interval);
void schedule_event(struct event *ev, int first_t);
int check_events(int now);

struct source *iat_get_source(void);  /* source +source_info */
struct source_info *iat_get_source_info(void);  /* source_info+flow_info */
void iat_free_source_info(struct source *sp); 

void get_flow_info(struct source *sp);  //2.1 flow_info only
void init_flow_info(struct source *sp);
void free_flow_info(struct source *sp);
void iat_free_source(struct source *sp);  //2.1 was free_source
void source_fl_check(void);

void init_mutex(pthread_mutex_t *m, char const *name);
void _mutexes(void);

#define mutex_lock(caller,m)  tw_pthread_mutex_lock(m)
#define mutex_unlock(caller,m)  tw_pthread_mutex_unlock(m)

int get_usage(struct iat_usage *itp);

#define v6cmp(s, d)  memcmp(s.a, d.a, IP6_ADDR_LEN)
char *v6addr_to_s(char *v6a, struct ip_address *addrp);
char *key_to_s(struct source *sp);

struct iat_ht *iat_ht_create(int mxhtentries);
uint32_t iat_hash(struct pkt_info *pp);
struct source *iat_ht_lookup(struct iat_ht *t, uint32_t hash,
   struct pkt_info *record, int *OK_to_add);
   /* returns record, NULL if not found */
void iat_ht_delete(struct iat_ht *t, void *record);
   /* deletes specified record */

int addr_is_local(int kind, struct ip_address *addrp);

void reset_summary_info(void);
void update_summary_info(struct source *sp);

void count_uint16(uint16_t p, struct topn_uint16 *tnp);
void count_uint8(uint8_t p, struct topn_uint8 *tnp);
void count_addrs4(struct ip_address *p, struct topn_dst_addrs4 *tnp);
void count_addrs6(struct ip_address *p, struct topn_dst_addrs6 *tnp);
int update_flow_info(struct source *sp, struct pkt_info *ipp);

uint16_t top_uint16(struct topn_uint16 *tnp);
uint8_t top_uint8(struct topn_uint8 *tnp);
uint32_t top_addrs4(struct topn_dst_addrs4 *tnp);
int analyse_flow(struct source *sp);

char *strmov(char *d, char *s);
void print_topn_dst_addrs4(struct topn_dst_addrs4 *tnp);
void print_topn_dst_addrs6(struct topn_dst_addrs6 *tnp);
void print_topn_uint8(struct topn_uint8 *tnp);
void print_topn_uint16(struct topn_uint16 *tnp);
void print_flow_info(struct source *sp);

void init_ua_variables(void);
void update_ua_stats(struct source *sp);


#include "hashtable.h"  /* C hashtable by Christopher Clark
                           https://github.com/davidar/c-hashtable */
#include "hashtable_itr.h"

#if HALF_WAY_SOURCES  /* For src_addr ht */
struct addr_key { struct ip_address key; };
struct addr_key_val { struct ip_address key; uint32_t count; };
extern struct hashtable *half_src_addrs;

unsigned int hashfromaddr(void *ky);
int equaladdrs(void *ky1, void *ky2);
void addr_ht_insert(struct hashtable *h, struct ip_address *addr);

int addr_kv_cmp(const void *a, const void *b);
struct addr_key_val *addr_get_kv(struct hashtable *h, int *length);
#endif

#if ERF_DIRECTION
void update_direction_counts(struct source *sp);
#endif

struct key { uint32_t key; };  /* For port and tcp_key hts */
struct key_val { uint32_t key, count; };
extern struct hashtable *ua_dst_ports, *ua_tcp_keys;

unsigned int hashfromkey(void *ky);
int equalkeys(void *ky1, void *ky2);
void iat_ht_insert(struct hashtable *h, uint32_t tk);
int kv_cmp(const void *a, const void *b);
struct key_val *get_kv( struct hashtable *h, int *length);

extern int deleted_inactive, n_sources_written;
void delete_source(struct source *sp);
int update_source_attribs(struct source *sp);

#endif /* __IATMON_H */
