/* 1154, Wed 23 May 12 (PDT)
   1541, Thu 17 Mar 11 (PDT)
   1700, Sat 17 Dec 10 (NZDT)
   1955, Thu 22 Apr 10 (PDT)
   1445, Wed  5 Dec 07 (NZDT)

   iat-support.c:  Support routines for iatmon

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2013 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "iat.h"  /* Also includes iat-smee.h */

/* Define global variables (declared extern in iat.h) */

void (*log_msg)(void *user_data, int priority, int die, char const *fmt, ...);
int (*stat_printf)(void *user_data, const char *fmt, ...);
int (*sum_printf)(void *user_data, const char *fmt, ...);
int (*sources_printf)(void *user_data, const char *fmt, ...);
uint64_t (*pkt_drops)(void *user_data);
 
char *logname;
FILE *log_file;
struct source *extra_sources[MX_EXTRA_BLOCKS+1];
int extra_source_incr, n_extra_sources;
const char *iat_trace_name, *iat_meter_loc;

#if MKSTATSCOUNTS
uint32_t  /* Per-interval stats arrays for each source type .. */
   **active_sources_per_stats_interval, *active_sources_this_interval,
   **unique_hosts_per_stats_interval, *unique_hosts_this_interval;
uint32_t stats_interval_nbr;
#endif

#if MKDESTCOUNTS
uint32_t **dest_addrs_per_source_type;
#define src_addr_bin(a)  ((ntohl(a) >> 24) & 0x000000FF)  /* 1st byte */
uint32_t (*dest_addr_bin)(uint32_t a);
#endif

struct ip_address *la;
int n_local_addrs,
   mx_life;  /* For source lifetime distributions */
int local_v6;  /* 1 if we have a v6 local address */

int n_source_types, pkts_to_record, min_pkts_to_classify,
  traces_to_process, mx_sources;

int time_rec_interval, intervals_this_sum_file;

int n_lost_source_v4s, n_lost_source_v6s;
uint64_t last_drops;

int mx_active_sources, mx_active_pkt_infos, mx_active_source_infos,
   mx_active_v4_flow_infos, mx_active_v6_flow_infos,
   av_cl_count, n_hc_searches;

int av_pkt_count, mx_pkt_count, stats_seconds, pkts_this_second;

#if HALF_WAY_SOURCES
struct hashtable *half_src_addrs;
#endif

uint64_t      /* Packets counted by various threads; reset */
   pkts_from_trace,  /*  i.e. passed to process_packet() */
   t_not_ip, t_frags, t_too_small, t_no_local_address, t_v6_opaque,
   t_twolocaladdrs, pkts_at_flow_watchers, pkts_to_ob;

int          /* Packets discarded by flow_watcher; reset
                       every TIME_INTERVAL (i.e. #Stats log_msg) */
   n_not_ip, n_frags, n_too_small, n_no_local_address, n_v6_opaque;

uint64_t  /* Overall stats */
   v4_one_way_bytes,  v4_one_way_pkts,  v4_one_way_sources,
   v6_one_way_bytes,  v6_one_way_pkts,  v6_one_way_sources,
   v4_two_way_bytes,  v4_two_way_pkts,  v4_two_way_sources,
   v6_two_way_bytes,  v6_two_way_pkts,  v6_two_way_sources,
   v4_half_way_bytes, v4_half_way_pkts, v4_half_way_sources,
   v6_half_way_bytes, v6_half_way_pkts, v6_half_way_sources;

#if ERF_DIRECTION
 uint64_t
   one_way_sources_1, one_way_sources_2, one_way_sources_3,
   two_way_sources_1, two_way_sources_2, two_way_sources_3, 
   half_way_sources_1, half_way_sources_2, half_way_sources_3;
#endif

time_t start_tt;  /* Seconds part of first-packet */
int start_ts,
   last_ts;         /*    and last-packet timestamps */

struct event event_q;  /* Queue of active events, dummy first member */

pthread_mutex_t
   source_data_mutex,  /* source data (packet/byte counts) */
   n_fw_mutex,         /* n_fw_running */
   count_mutex;        /* lock for count/count_cv */

pthread_cond_t count_cv;
int ct_count;  /* Nbr of check_timeouts() running */

struct flow_watcher_control **fwa;
int n_flow_watchers, fw_next_st_to_check;

int n_fw_running;  /* Nbr of flow watchers running */

#include <sys/utsname.h>
struct utsname node;  /* Info about the host we're nunning on */

int request_shutdown,  /* True to stop iatmon */
   smee_return_code;
int live_source;  /* Zero for trace files */


struct iat_usage iu1, iu2;

void quack(int agent) {
   log_msg(user_data, LOG_ERR, 0,  "***** quack(%d) *****\n", agent);
   }

iat_mem_declare_functions(event);

struct event *get_iat_event(int t, int interval) {  /* Get an unused event */
   struct event *e = get_event();
   if (e != NULL) {
      e->type = t;  e->interval = interval;
      return e;
      }
   else return NULL;
   }

void schedule_event(struct event *ev, int first_t) {
   struct event *eqp, *lqp;

   if (ev == NULL) log_msg(user_data,
      LOG_WARNING, 0, "Tried to schedule NULL event!");

   ev->t = first_t;
   lqp = &event_q;  eqp = event_q.next;
   for ( ; eqp != NULL; lqp = eqp, eqp = eqp->next) {
      if (ev->t <= eqp->t) break;  /* Closest to head */
      }
   lqp->next = ev;  ev->next = eqp;
   }

int check_events(int now) {
   struct event *ep;
   uint32_t e_type;

   ep = event_q.next;

   if (ep == NULL || ep->t > now) {
      return NO_EVENT;
      }
   event_q.next = ep->next;  /* Remove from event queue */
   e_type = ep->type;

   if (ep->interval != 0)
      schedule_event(ep, ep->t += ep->interval);
   else free_event(ep);

   return e_type;
   }

iat_mem_declare_functions(distribution);
iat_mem_declare_functions(v4_flow_info);
iat_mem_declare_functions(v6_flow_info);

iat_mem_declare_functions(source_info);
iat_mem_declare_functions(source);
iat_queue_declare_functions(source);

iat_mem_declare_functions(pkt_info);
iat_pcq_declare_functions(pkt_info);

struct source *iat_get_source(void) {  /* Get an unused source */
   struct source *sp = get_source();
   if (sp == NULL) {
      log_msg(user_data, LOG_ERR, 0,
         "More than %d source objects needed <<<", source_allowed());
      request_shutdown = 1;
      return NULL;
      }
   sp->d.si = iat_get_source_info();
   return sp;
   }

struct source_info *iat_get_source_info(void) {
   struct source_info *sip;
   if ((sip = get_source_info()) == NULL)
      log_msg(user_data, LOG_ERR, 0, "Couldn't get a source_info object");
   return sip;
   }

void iat_free_source_info(struct source *sp) {  /* source pointer */
   if (sp->d.si == NULL) return;
   if (sp->d.si->fi != NULL) free_flow_info(sp);
   free_source_info(sp->d.si);
   sp->d.si = NULL;
   }

void get_flow_info(struct source *sp) {  /* Get flow_info for a source */
   if (sp->d.si == NULL) return;
   if (sp->version == 4) {
     if ((sp->d.si->fi = (struct flow_info *)get_v4_flow_info())
         == NULL) return;  /* Couldn't get flow_info */
      }
   else {
     if ((sp->d.si->fi = (struct flow_info *)get_v6_flow_info())
         == NULL) return;  /* Couldn't get flow_info */
      }
   init_flow_info(sp);
   if ((sp->d.si->fi->d = get_distribution()) == NULL)
      return;  /* Couldn't get distribution */
   init_distrib(sp->d.si->fi->d, LOWER_IAT,  UPPER_IAT,
      MXBUCKETS, DS_LOG_DIF);
   }

void free_flow_info(struct source *sp) {
   if (sp->d.si == NULL || sp->d.si->fi == NULL) return;
   if (sp->d.si->fi->d != NULL) {
      free_distribution(sp->d.si->fi->d);
      sp->d.si->fi->d = NULL;
      }
   if (sp->version == 4)
      free_v4_flow_info((struct v4_flow_info *)sp->d.si->fi);
   else free_v6_flow_info((struct v6_flow_info *)sp->d.si->fi);
   sp->d.si->fi = NULL;
   }

void iat_free_source(struct source *sp) {  /* Return source to free list */
   sp->state = SS_FREE;
   if (sp->d.si != NULL) free_source_info(sp->d.si);
   free_source(sp);
   }

iat_mem_declare_functions(flow_watcher_control)

void init_mutex(pthread_mutex_t *m, char const *name) {
   if (pthread_mutex_init(m, pthread_mutexattr_default) == -1)
      log_msg(user_data, LOG_ERR, 6, "Couldn't init %s", name);
   }

void init_mutexes(void) {
   init_mutex(&n_fw_mutex, "n_fw_mutex");
   init_mutex(&count_mutex, "count_mutex");
   }

uint64_t file_size(const char *uri) {
   char *fnp;  struct stat fstat;

   if (!live_source) {
      fnp = strstr(uri, ":");
      if (stat(fnp+1, &fstat) < 0) return -1;
      return fstat.st_size;
      }
   else return -1;
   }

int get_usage(struct iat_usage *itp) {
   struct timeval tv;  struct rusage ru;  int r;
   itp->mxrss = -1;
   r = gettimeofday(&tv, NULL);
   if (r != 0) return 0;
   itp->tod = (double)tv.tv_sec + tv.tv_usec/1000000.0;
   r = getrusage(RUSAGE_SELF, &ru);
   if (r != 0) return 0;
   itp->tuser =  (double)ru.ru_utime.tv_sec + 
      ru.ru_utime.tv_usec/1000000.0;
   itp->tsystem =  (double)ru.ru_stime.tv_sec +
      ru.ru_stime.tv_usec/1000000.0;
   itp->mxrss = (double)ru.ru_maxrss/1000000.0;  /* GB */
   return 1;
   }

char *strmov(char *d, char *s) {
   while (*s != '\0') *d++ = *s++;
   return d;
   }

char *v6addr_to_s(char *v6a, struct ip_address *p)
{  /* Returns pointer to next byte in v6a 
      Code from NeTraMet's nmc_pars.c */
   char buf[10];  /* RFC 2373: IPv6 Address Architecture */
   char *d = v6a;
   char *a = (char *)p->a.a;
   int j, k, st,len, stx = 0,lenx;
   uint32_t v, a2[8];

   st = len = lenx = 0;
   for (k = j = 0; j != 16; j += 2) {
      v =  ntohs(*(uint16_t *)&a[j]);
      a2[k++] = v;          /* Build array of two-byte pairs */
      if (v == 0) ++len;
      else {
         if (len > lenx) {  /* Find longest run of zero pairs */
            stx = st;  lenx = len;
	    }
         st = k;  len = 0;
         }
      }

   if (len > lenx) {
      stx = st;  lenx = len;
      }
   if (lenx != 0 && stx == 0) {  /* Longest run at left */
     d = strmov(d, (char *)":");  j = lenx;
      }
   else {
      sprintf(buf, "%x", a2[0]);
      d = strmov(d,buf);  j = 1;
      }
   for (; j < 8; ) {
      if (lenx != 0 && j == stx) {
	d = strmov(d,(char *)":");  j += lenx;
         }
      else {
         sprintf(buf, ":%x", a2[j]);
         d = strmov(d, buf);  ++j;
         }
      }
   if (j == stx+lenx) d = strmov(d, (char *)":");  /* Longest run at right */
   *d = '\0';
   return d;
}

struct iat_ht *iat_ht_create(int mx_hash_entries) {
   struct iat_ht *new_htbl = malloc(sizeof(struct iat_ht));
   /* Each hash table is only used by a single flow_watcher, so
      we don't need to lock the table while making changes to it */
   new_htbl->table_size = mx_hash_entries;
   new_htbl->sfht = (void **)malloc(mx_hash_entries*sizeof(void *));
   if (new_htbl->sfht == NULL)
      log_msg(user_data, LOG_ERR, 7,
         "Not enough memory for source hash table!");
   memset(new_htbl->sfht, 0, new_htbl->table_size*sizeof(void *));
   return new_htbl;
   }

uint32_t iat_hash(struct pkt_info *sp) {
    /* source hash, determines flow_watcher for every packet,
          also determines source the packet belongs to */
   if (sp->version == 4) {
      return (sp->src_addr.a.v4 >> 9) + sp->src_addr.a.v4 * 5;
      }
   else {  /* v6 source */
      return sp->src_addr.a.o.q0 ^ sp->src_addr.a.o.q1 ^
	 sp->src_addr.a.o.q2 ^ sp->src_addr.a.o.q3 ^ (6 * 96953);
#if 0
      uint64_t hh = 
 	 sp->src_addr.a.o.oct0 ^ sp->src_addr.a.o.oct1;
      return ((uint32_t *)&hh)[1] ^ ((uint32_t *)&hh)[0] ^ (6 * 96953);
      +      /* 10/26/12 - ak fixes this to prevent gcc from complaining */
	+      /* also, this is not portable */
	+      /* assume nevil meant the second least significant byte? */
	+      uint64_t h1 = (hh & 0xff00) >> 8;
      +      /* assume nevil meant the least significant byte? */
	+      uint64_t h2 = hh & 0xff;
      +      /*return ((uint32_t *)&hh)[1] ^ ((uint32_t *)&hh)[0] ^ (6 * 96953);*/
	+      return h1 ^ h2 ^ (6 * 96953);
#endif
      }
   }

uint32_t iat_compare(struct pkt_info *pp, struct source *sh_entry) {
   if (pp->version == 4) {
      return
	 pp->src_addr.a.v4 == sh_entry->src_addr.a.v4 &&
         pp->version == sh_entry->version;
      }
   else {  /* v6 source */
      return
         pp->src_addr.a.o.oct1 == sh_entry->src_addr.a.o.oct1 &&
	 pp->src_addr.a.o.oct0 == sh_entry->src_addr.a.o.oct0 &&
         pp->version == sh_entry->version;
      }
   }

struct source *iat_ht_lookup(struct iat_ht *t, uint32_t hash,
      struct pkt_info *pp, int *OK_to_add) {
   struct source **sha;
   struct source *shte, *lshte = NULL, *sp;
   int cl;

   sha = (struct source **)&t->sfht[hash % t->table_size];
      /* Address of source hash table entry */
   if ((shte = *sha) == NULL) {
      lshte = NULL;  /* Empty hash chain */
      }
   else {
      for (cl = 1; ; cl += 1) {
 	 if (iat_compare(pp, shte)) break;  /* Matched */
         lshte = shte;
         if ((shte = lshte->next_hc) == (struct source *)sha) {
            shte = NULL;  break;
            /* Loop stops with lshte -> last source in chain */
	    }
         }
      av_cl_count += cl;  n_hc_searches += 1;
      }

   if (shte != NULL) {  /* Existing source */
      *OK_to_add = 0;
      return shte;
      }
   else if (!*OK_to_add) {  /* Not in source table */
      return NULL;
      }
   else {  /* Enter record in source table */
      sp = iat_get_source();  /* Gets source + source_info */
      if (lshte == NULL) *sha = sp;  /* Add source to hash chain */
      else lshte->next_hc = sp;
      sp->next_hc = (struct source *)sha;
      *OK_to_add = 1;  /* We added this source */
      return sp;
      }
   }

void iat_ht_delete(struct iat_ht *t, void *record) {
   struct source *sp, *np, *tp, *ltp;

   sp = (struct source *)record;
   np = sp->next_hc;  /* Remove source from hash chain */
   tp = sp;  do {
      ltp = tp;
      } while ((tp = tp->next_hc) != sp);
   if (ltp == np)  /* Single flow in hash chain */
      np->next_hc = NULL;
   else ltp->next_hc = np;
   sp->next_hc = NULL;
   }

static uint8_t p_mask[8] = { 0x00, 0x80, 0xC0, 0xE0, 0xF0, 0xF8, 0xFC, 0xFE };

int addr_is_local(int ver, struct ip_address *addrp) {  /* in local_addrs[] */
   int j, nb,k, len;
   uint8_t *a = addrp->a.a;
   for (j = 0; j != n_local_addrs; ++j) {
      if (la[j].ver == ver) {
	 len = la[j].len;
         nb = len/8;  /* whole bytes */
         for (k = 0; k != nb; ++k)
            if (a[k] != la[j].a.a[k]) break;
         if (k != nb) return 0;  /* false */
         if (k*8 == len) return 1;  /* Match up to length */
         return ((a[k] ^ la[j].a.a[k]) & p_mask[len%8]) == 0;
         }
      }   
   return 0;
   }

void reset_summary_info(void) {
   v4_one_way_bytes     = v4_one_way_pkts  = v4_one_way_sources =
      v6_one_way_bytes  = v6_one_way_pkts  = v6_one_way_sources = 
      v4_two_way_bytes  = v4_two_way_pkts  = v4_two_way_sources =
      v6_two_way_bytes  = v6_two_way_pkts  = v6_two_way_sources =
      v4_half_way_bytes = v4_half_way_pkts = v4_half_way_sources =
      v6_half_way_bytes = v6_half_way_pkts = v6_half_way_sources = 0;
   pkts_from_trace = pkts_at_flow_watchers = pkts_to_ob = 0;
   t_not_ip = t_frags = t_too_small = t_no_local_address = 
      t_twolocaladdrs = t_v6_opaque = 0;

#if ERF_DIRECTION
   one_way_sources_1 = one_way_sources_2 = one_way_sources_3 =
      two_way_sources_1 = two_way_sources_2 = two_way_sources_3 =
      half_way_sources_1 = half_way_sources_2 = half_way_sources_3 = 0;
#endif
#if HALF_WAY_SOURCES
   half_src_addrs = create_hashtable(5000, hashfromaddr, equaladdrs);
#endif
#if MKDESTCOUNTS
   int j;
   for (j = 0; j != n_source_types; ++j) {
      memset(dest_addrs_per_source_type[j], 0, NDESTBINS*sizeof(uint32_t));
      }
#endif
   }

#if ERF_DIRECTION
void update_direction_counts(struct source *sp) {
  if (sp->state == SS_TWO_WAY || sp->state == SS_WAS_TWO_WAY) {
    if (sp->d.si == NULL) return;
    if (sp->d.si->direction == 1) two_way_sources_1 += 1;
    else if (sp->d.si->direction == 2) two_way_sources_2 += 1;
    else two_way_sources_3 += 1;
  }
  else if (sp->state == SS_ONE_WAY) {
    if (sp->d.si == NULL) return;
    if (sp->d.si->direction == 1) one_way_sources_1 += 1;
    else if (sp->d.si->direction == 2) one_way_sources_2 += 1;
    else one_way_sources_3 += 1;
  }
  else if (sp->d.si != NULL) {
    if (sp->d.si->direction == 1) half_way_sources_1 += 1;
    else if (sp->d.si->direction == 2) half_way_sources_2 += 1;
    else half_way_sources_3 += 1;
  }
}
#endif

void update_summary_info(struct source *sp) {
#if ERF_DIRECTION
   update_direction_counts(sp);
#endif
   if (sp->state == SS_TWO_WAY) {
      if (sp->version == 4) {
	 v4_two_way_bytes += (sp->d.si->tb + sp->d.si->fb);
	 v4_two_way_pkts += (sp->d.si->tp + sp->d.si->fp);
         v4_two_way_sources += 1;
 	 }
      else {
         v6_two_way_bytes += (sp->d.si->tb + sp->d.si->fb);
         v6_two_way_pkts += (sp->d.si->tp + sp->d.si->fp);
         v6_two_way_sources += 1;
         }
      }
#if HALF_WAY_SOURCES
   else if (sp->state == SS_HALF_WAY) {
      if (sp->version == 4) {
	 v4_half_way_bytes += (sp->d.si->tb + sp->d.si->fb);
	 v4_half_way_pkts += (sp->d.si->tp + sp->d.si->fp);
         v4_half_way_sources += 1;
         addr_ht_insert(half_src_addrs, &sp->src_addr);
 	 }
      else {
         v6_half_way_bytes += (sp->d.si->tb + sp->d.si->fb);
         v6_half_way_pkts += (sp->d.si->tp + sp->d.si->fp);
         v6_half_way_sources += 1;
         addr_ht_insert(half_src_addrs, &sp->src_addr);
         }
      }
#endif
    }


void init_flow_info(struct source *sp) {  /* Zero flow_info for a source */
   struct flow_info *fi = sp->d.si->fi;
   fi->tcp_key = fi->cfc_count = fi->uT_count = 0;
   fi->tn_tcp.nv = fi->tn_udp.nv =
      fi->tn_flags.nv = fi->tn_proto.nv = fi->tn_ttl.nv =
      fi->tn_src_port.nv = fi->tn_iplen.nv = 0;

   if (sp->version == 4) {
      fi->v.v4.tn_dst_addrs.nv = 0; 
#if HALF_WAY_SOURCES
      fi->v.v4.pkts_this_dst = 0;
#endif
      }
   else {
      fi->v.v6.tn_dst_addrs.nv = 0; 
#if HALF_WAY_SOURCES
      fi->v.v6.pkts_this_dst = 0;
#endif
      }
   }

void count_uint16(uint16_t p, struct topn_uint16 *tnp) {
   uint32_t j;
   for (j = 0; j != tnp->nv; j += 1) {
      if (p == tnp->values[j]) {
	 tnp->counts[j] += 1;  return;
	 }
      }
   if (j != MX_N_UINT16) {
      tnp->values[j] = p;  tnp->counts[j] = 1;
      tnp->nv += 1;
      }
   }

void count_uint32(uint32_t p, struct topn_uint32 *tnp) {
   uint32_t j;
   for (j = 0; j != tnp->nv; j += 1) {
      if (p == tnp->values[j]) {
	 tnp->counts[j] += 1;  return;
	 }
      }
   if (j != MX_N_UINT16) {
      tnp->values[j] = p;  tnp->counts[j] = 1;
      tnp->nv += 1;
      }
   }

void count_uint8(uint8_t p, struct topn_uint8 *tnp) {
   uint32_t j;
   for (j = 0; j != tnp->nv; j += 1) {
      if (p == tnp->values[j]) {
	 tnp->counts[j] += 1;  return;
	 }
      }
   if (j != MX_N_UINT8) {
      tnp->values[j] = p;  tnp->counts[j] = 1;
      tnp->nv += 1;
      }
   }

void count_addrs4(struct ip_address *p, struct topn_dst_addrs4 *tnp) {
   uint32_t j;
   for (j = 0; j != tnp->nv; j += 1) {
      if (p->a.v4 == tnp->values[j].a.v4) {
	 tnp->counts[j] += 1;  return;
	 }
      }
   if (j != V4_SET_SIZE) {
      tnp->values[j].a.v4 = p->a.v4;  tnp->counts[j] = 1;
      tnp->nv += 1;
      }
   }

void count_addrs6(struct ip_address *p, struct topn_dst_addrs6 *tnp) {
   uint32_t j;
   for (j = 0; j != tnp->nv; j += 1) {
      if (p->a.o.oct0 == tnp->values[j].a.o.oct0 &&
            p->a.o.oct1 == tnp->values[j].a.o.oct1) {
	 tnp->counts[j] += 1;  return;
	 }
      }
   if (j != V6_SET_SIZE) {
      tnp->values[j].a.o.oct0 = p->a.o.oct0;
      tnp->values[j].a.o.oct1 = p->a.o.oct1;
      tnp->counts[j] = 1;  tnp->nv += 1;
      }
   }

uint8_t top_uint8(struct topn_uint8 *tnp) {
   if (tnp->nv == 0) return 0;
   uint16_t j, mj = 0;
   uint32_t mxcount = tnp->counts[0];
   for (j = 1; j != tnp->nv; j += 1) {
      if (tnp->counts[j] > mxcount) {
         mj = j;  mxcount = tnp->counts[j];
	 }
      }
   return tnp->values[mj];
   }

uint16_t top_uint16(struct topn_uint16 *tnp) {
   if (tnp->nv == 0) return 0;
   uint32_t j, mj = 0,
      mxcount = tnp->counts[0];
   for (j = 1; j != tnp->nv; j += 1) {
     if (tnp->counts[j] > mxcount) {
         mj = j;  mxcount = tnp->counts[j];
	 }
      }
   return tnp->values[mj];
   }

uint32_t top_uint32(struct topn_uint32 *tnp) {
   if (tnp->nv == 0) return 0;
   uint32_t j, mj = 0,
     mxcount = tnp->counts[0];
   for (j = 1; j != tnp->nv; j += 1) {
     if (tnp->counts[j] > mxcount) {
         mj = j;  mxcount = tnp->counts[j];
	 }
      }
   return tnp->values[mj];
   }

uint32_t top_addrs4(struct topn_dst_addrs4 *tnp) {
   if (tnp->nv == 0) return 0;
   uint32_t j, mj = 0,
     mxcount = tnp->counts[0];
   for (j = 0; j != tnp->nv; j += 1) {
     if (tnp->counts[j] > mxcount) {
         mj = j;  mxcount = tnp->counts[j];
	 }
      }
   return tnp->values[mj].a.v4;
   }

uint32_t top_addrs6(struct topn_dst_addrs6 *tnp) {
   if (tnp->nv == 0) return 0;
   uint32_t j, mj = 0,
     mxcount = tnp->counts[0];
   for (j = 0; j != tnp->nv; j += 1) {
     if (tnp->counts[j] > mxcount) {
         mj = j;  mxcount = tnp->counts[j];
	 }
      }
   /*return *(uint32_t *)&tnp->values[mj].a.a;*/
   return tnp->values[mj].a.o.q0;
   }

int top2_uint8(struct topn_uint8 *tnp, int *v2) {
   if (tnp->nv == 0) {
      *v2 = -1;  return -1;
      }
   uint32_t j, mj = 0, mj2 = 0,
      mxcount = tnp->counts[0],
      mx2 = 0;
   if (tnp->nv == 0) {
      *v2 = -1; return -1;
      }
   for (j = 1; j != tnp->nv; j += 1) {
      if (tnp->counts[j] > mxcount) {
         mj2 = mj;  mx2 = mxcount;
         mj = j;  mxcount = tnp->counts[j];
	 }
      else if (tnp->counts[j] > mx2) {
         mj2 = j;  mx2 = tnp->counts[j];
         }
      }
   *v2 = mx2 == 0 ? -1 : tnp->values[mj2];
   return tnp->values[mj];
   }

int top2_uint16(struct topn_uint16 *tnp, int *v2) {
   if (tnp->nv == 0) {
      *v2 = -1;  return -1;
      }
   uint32_t j, mj = 0, mj2 = 0,
      mxcount = tnp->counts[0],
      mx2 = 0;
   if (tnp->nv == 0) {
      *v2 = -1; return -1;
      }
   for (j = 1; j != tnp->nv; j += 1) {
      if (tnp->counts[j] > mxcount) {
         mj2 = mj;  mx2 = mxcount;
         mj = j;  mxcount = tnp->counts[j];
	 }
      else if (tnp->counts[j] > mx2) {
         mj2 = j;  mx2 = tnp->counts[j];
         }
      }
   *v2 = mx2 == 0 ? -1 : tnp->values[mj2];
   return tnp->values[mj];
   }

int update_flow_info(struct source *sp, struct pkt_info *ipp) {
   /* Update sp flow info from 'this packet' fields in isp,
      returns 1 if we've seen increasing TCP seq or ack */
   struct flow_info *fi;
   if (sp->d.si == NULL) return 0;
   fi = sp->d.si->fi;
   if (fi == NULL) {
     log_msg(user_data, LOG_WARNING, 0,
        "Tried to update non-existent flow_info!");
      return 0;
      }
   if (fi->d != NULL) bump_dist(fi->d, ipp->at_s);
      /* bump_dist() expects last_s, computes IAT from it */
   fi->cfc_count += ipp->cfc;
   fi->uT_count += ipp->uTorrent;
   count_uint16(ipp->ip_len, &fi->tn_iplen);
   count_uint8(ipp->ttl, &fi->tn_ttl);
   count_uint8(ipp->proto, &fi->tn_proto);
   switch (ipp->proto) {
   case PT_TCP:
      count_uint16(ipp->dst_port, &fi->tn_tcp);
      count_uint16(ipp->src_port, &fi->tn_src_port);
      count_uint8(ipp->tcp_flags, &fi->tn_flags);
      break;
   case PT_UDP:
      count_uint16(ipp->dst_port, &fi->tn_udp);
      count_uint16(ipp->src_port, &fi->tn_src_port);
      break;
   case PT_ICMP:
      count_uint16(ipp->dst_port, &fi->tn_tcp);  /* ICMP type|code */
      break;
      }
   if (sp->version == 4) {
      count_addrs4(&ipp->dst_addr, &fi->v.v4.tn_dst_addrs);
#if HALF_WAY_SOURCES
      if (ipp->proto == PT_TCP) {
         if (fi->v.v4.pkts_this_dst == 0) {  /* New source */
            fi->v.v4.prev_dst.a.v4 = ipp->dst_addr.a.v4;
            fi->v.v4.prev_seq = ipp->tcp_seq;
            fi->v.v4.prev_ack = ipp->tcp_flags & 0x10 ? ipp->tcp_ack :
               0;  /* No ACK flag, guess first ACK value (!) */
            fi->v.v4.pkts_this_dst = 1;
	    }
         else {
	    if (ipp->dst_addr.a.v4 != fi->v.v4.prev_dst.a.v4) {
 	       fi->v.v4.prev_dst.a.v4 = ipp->dst_addr.a.v4;  /* New dst */
               fi->v.v4.prev_seq = ipp->tcp_seq;
               fi->v.v4.prev_ack = ipp->tcp_ack;
               fi->v.v4.pkts_this_dst = 1;
	       }
 	    else if (ipp->tcp_seq > fi->v.v4.prev_seq) {
	       fi->v.v4.prev_seq = ipp->tcp_seq;  fi->v.v4.pkts_this_dst += 1;
	       }
            else if ((ipp->tcp_flags & 0x10) &&
                  ipp->tcp_ack > fi->v.v4.prev_ack) {
	       fi->v.v4.prev_ack = ipp->tcp_ack;  fi->v.v4.pkts_this_dst += 1;
	       }
	    }
         }
      return fi->v.v4.pkts_this_dst >= HALF_ONE_WAY_PKTS;
#else
      return 0;
#endif
      }
   else {  /* v6 */
      count_addrs6(&ipp->dst_addr, &fi->v.v6.tn_dst_addrs);
#if HALF_WAY_SOURCES
      if (ipp->proto == PT_TCP) {
         if (fi->v.v6.pkts_this_dst == 0) {  /* New source */
 	    fi->v.v6.prev_dst.a.o.oct0 = ipp->dst_addr.a.o.oct0;
	    fi->v.v6.prev_dst.a.o.oct1 = ipp->dst_addr.a.o.oct1;
            fi->v.v6.prev_seq = ipp->tcp_seq;
            fi->v.v6.prev_ack = ipp->tcp_flags & 0x10 ? ipp->tcp_ack :
               0;  /* No ACK flag, guess first ACK value (!) */
            fi->v.v6.pkts_this_dst = 1;
	    }
         else {
	   if (ipp->dst_addr.a.o.oct0 != fi->v.v6.prev_dst.a.o.oct0 ||
	          ipp->dst_addr.a.o.oct1 != fi->v.v6.prev_dst.a.o.oct1) {
 	       fi->v.v6.prev_dst.a.o.oct0 = ipp->dst_addr.a.o.oct0;
	       fi->v.v6.prev_dst.a.o.oct1 = ipp->dst_addr.a.o.oct1;
               fi->v.v6.prev_seq = ipp->tcp_seq;
               fi->v.v6.prev_ack = ipp->tcp_ack;
               fi->v.v6.pkts_this_dst = 1;
	       }
 	    else if (ipp->tcp_seq > fi->v.v6.prev_seq) {
	       fi->v.v6.prev_seq = ipp->tcp_seq;  fi->v.v6.pkts_this_dst += 1;
	       }
            else if ((ipp->tcp_flags & 0x10) &&
                  ipp->tcp_ack > fi->v.v6.prev_ack) {
	       fi->v.v6.prev_ack = ipp->tcp_ack;  fi->v.v6.pkts_this_dst += 1;
	       }
            }
         }
      return fi->v.v6.pkts_this_dst >= HALF_ONE_WAY_PKTS;
#else
      return 0;
#endif
      }
   }

int src_port, probe_port;  /* analyse_flow() results */
int flags_mode, keys_mode, iplen_mode;
int probe_port_valid,   /* (other than src_type) */
   too_few_pkts,      /* < MinPkts */
   protocol, ttl_mode;

double b0pc, modeiat, skew;  /* compute_distrib_stats() results */
int nz_runs;

uint32_t old_dns[N_source_types];  //old_dns
int old_dbs;  //old_dns

void *user_data;  /* From Corsaro */

int analyse_flow(struct source *sp) {
      /* Determine source kind from flow info */
   struct flow_info *fi = sp->d.si->fi;
#if NON_CONF_TEST
   double ab_dest_pc;
#endif
   old_dbs = 0;  //old_dns
   probe_port_valid = 0;
   flags_mode = keys_mode = src_port = 0;
   iplen_mode = top_uint16(&fi->tn_iplen);
   ttl_mode = top_uint8(&fi->tn_ttl);
   protocol = top_uint8(&fi->tn_proto);

   too_few_pkts = sp->totp < (uint32_t)min_pkts_to_classify;
   if (too_few_pkts) return S_1_or_2_packets;

   if (fi->tn_proto.nv == 1) {  /* Single protocol */
      if (protocol == PT_TCP) {
         flags_mode = top_uint8(&fi->tn_flags);
         keys_mode = fi->tcp_key;
         if (flags_mode == 18 || flags_mode == 20)
            /* TCP ACK+SYN or ACK+RST */
            return S_backscatter_tcp;
         if (fi->cfc_count >= sp->totp*CFC_FRACTION)
            return S_conficker_c;
         if (fi->uT_count >= sp->totp*CFC_FRACTION)
            return S_utorrent;

         src_port = top_uint16(&fi->tn_src_port);
         if (src_port == PN_DNS) return S_backscatter_dns;
            /* Backscatter from a nameserver  3 Jun 12 */

	 if (fi->tn_tcp.nv == 1) {  /* Single dst_port */
	    probe_port = top_uint16(&fi->tn_tcp);  probe_port_valid = 1;
            if (probe_port == PN_DNS) old_dbs = 1;  //old_dns
               /* was tn_src_port!  26 Apr 12 */
            if (sp->version == 4 && fi->v.v4.tn_dst_addrs.nv == 1)
               return S_tcp_probe;
            else if (fi->v.v6.tn_dst_addrs.nv == 1)
               return S_tcp_probe;
            if (probe_port == 445) {
#if NON_CONF_TEST
 	       ab_dest_pc = sp->d.si->ab_dest*100.0/sp->d.si->tp;
               if (ab_dest_pc >= 100.0-CFC_EPSILON_PC)  /* Most pkts A/B */
		  return S_t445_dest_cfab;
	       else if (ab_dest_pc >= 25.0-CFC_EPSILON_PC
                     && ab_dest_pc <= 25.0+CFC_EPSILON_PC)
		  return S_t445_dest_random;
	       else return S_t445_dest_other;
#else
               return S_tcp_445_horiz_scan;
#endif
	       }
	    return S_tcp_horizontal_scan;
	    }
	 else {  /* >1 dst_port */
            if (sp->version == 4 && fi->v.v4.tn_dst_addrs.nv == 1)
               return S_tcp_vertical_scan;
            else if (sp->version == 6 && fi->v.v6.tn_dst_addrs.nv == 1)
               return S_tcp_vertical_scan;
	    return S_tcp_unknown;
	    }
	 }
      if (protocol == PT_UDP) {
	 if (fi->cfc_count >= sp->totp*CFC_FRACTION)
            return S_conficker_c;
	 if (fi->uT_count >= sp->totp*CFC_FRACTION)
            return S_utorrent;
	 src_port = top_uint16(&fi->tn_src_port);
         if (src_port == PN_DNS) return S_backscatter_dns;
            /* Backscatter from a nameserver  3 Jun 12 */

 	 if (fi->tn_udp.nv == 1) {  /* Single dst_port */
 	    probe_port = top_uint16(&fi->tn_udp);  probe_port_valid = 1;
            if (probe_port == PN_DNS) old_dbs = 1;  //old_dns
               /* was tn_src_port!  26 Apr 12 */
            if (sp->version == 4 && fi->v.v4.tn_dst_addrs.nv == 1)
               return S_udp_probe;
            else if (sp->version == 6 && fi->v.v6.tn_dst_addrs.nv == 1)
               return S_udp_probe;
	    return S_udp_horizontal_scan;
	    }
	 else {  /* >1 dst_port */
            if (sp->version == 4 && fi->v.v4.tn_dst_addrs.nv == 1)
               return S_udp_vertical_scan;
            else if (sp->version == 6 && fi->v.v6.tn_dst_addrs.nv == 1)
               return S_udp_vertical_scan;
	    return S_udp_unknown;
	    }
         }
      if (protocol == PT_ICMP) {
         int it = top_uint16(&fi->tn_tcp);  /* ICMP type */
         if (it == ICMP_TTL_EXCEEDED || it == ICMP_DST_UNREACHABLE)
            return S_backscatter_icmp;
         return S_icmp_only;
         }
      return S_unclassified;
      }
   else {
      protocol = top_uint8(&fi->tn_proto);
      if (fi->tn_proto.nv == 2 && (
            (fi->tn_proto.values[0] == PT_TCP &&
               fi->tn_proto.values[1] == PT_UDP) ||
            (fi->tn_proto.values[0] == PT_UDP &&
               fi->tn_proto.values[1] == PT_TCP) ) ) {
	 if (fi->cfc_count >= sp->totp*CFC_FRACTION) return S_conficker_c;
	 if (fi->uT_count >= sp->totp*CFC_FRACTION) return S_utorrent;
         else return S_tcp_and_udp;
         }
      switch (protocol) {
      case PT_TCP:  
         return S_tcp_unknown;
      case PT_UDP:
         return S_udp_unknown;
      default:
         return S_unclassified;
         }
      }
   return S_unclassified;
   }

void print_topn_uint8(struct topn_uint8 *tnp) {
   uint32_t j;
   printf("<n=%d,", tnp->nv);
   for (j = 0; j != tnp->nv;  j += 1)
      printf(" %u,%u", tnp->values[j], tnp->counts[j]);
   printf(">");
   }

void print_topn_uint16(struct topn_uint16 *tnp) {
   uint32_t j;
   printf("<n=%d,", tnp->nv);
   for (j = 0; j != tnp->nv;  j += 1)
      printf(" %u,%u", tnp->values[j], tnp->counts[j]);
   printf(">");
   }

void print_topn_dst_addrs4(struct topn_dst_addrs4 *tnp) {
   uint32_t j;
   printf("[n=%d,", tnp->nv);
   for (j = 0; j != tnp->nv;  j += 1) {
      uint8_t *a = tnp->values[j].a.a;
      printf(" %u.%u.%u.%u,%u", a[0],a[1],a[2],a[3], tnp->counts[j]);
      }
   printf("]");
   }

void print_topn_dst_addrs6(struct topn_dst_addrs6 *tnp) {
   uint32_t j;  char v6addr[70];
   printf("[n=%d,", tnp->nv);
   for (j = 0; j != tnp->nv;  j += 1) {
      char *kp = v6addr_to_s(v6addr,
         (struct ip_address *)&tnp->values[j]);
      kp[1] = '\0';
      printf(" %s,%u", v6addr, tnp->counts[j]);
      }
   printf("]");
   }

#include <math.h>

void init_distrib(struct distribution *d,
      double lower, double upper, int bins, int transform) {
   double N, D;
   memset(d, 0, sizeof(struct distribution));
   d->LowerLim = lower;  d->UpperLim = upper;  /* seconds */
   d->Buckets = bins;  d->Transform = transform;

   if (d->Buckets > MXBUCKETS) {
      log_msg(user_data, LOG_ERR, 0,
         "Distribution with > %d buckets **", MXBUCKETS);
      d->Buckets = MXBUCKETS;
      }

   N = d->Buckets - 1;
   switch (d->Transform) {
   case DS_LIN_DIF:
   case DS_LIN:
      D = d->UpperLim - d->LowerLim;
      d->M = N/D;
      d->step = (d->UpperLim - d->LowerLim)/(d->Buckets-1);
      break;
   case DS_LOG_DIF:
   case DS_LOG:
      D = log10(d->UpperLim/d->LowerLim);
      d->M = N/D;
      d->step = (log10(d->UpperLim) - log10(d->LowerLim))/(d->Buckets-1);
      break;
      }
   }

void bump_dist(struct distribution *d, double y) {
      /* Called by update_flow_info, after pkt has been counted */
   double x, T;
   int n = 0;

   if (d->Transform == DS_LOG_DIF || d->Transform == DS_LIN_DIF) {
      if (d->total_count == 0) {  /* First packet */
         d->last_y = y;  d->total_count = 1;
         return;
         }
      x = y - d->last_y;  /* IAT (s) */
      d->last_y = y;  d->total_count += 1;
      }
   else x = y;

   if (x <= d->LowerLim) {  /* Determine bin to increment */
      d->bin0_count += 1;
      }
   else if (x > d->UpperLim) {
      d->counts8[C8-1] += 1;
      }
   else {
      switch (d->Transform) {
      case DS_LIN_DIF:
      case DS_LIN:
         T = (x - d->LowerLim) * d->M;
	 //  n = 1 + (int)floor(T);  /* n 1 too high when @t is an integer! */
         n = (int)ceil(T);  /* 23 Feb 2013 */
         break;
      case DS_LOG_DIF:
      case DS_LOG:
         T = log10(x/d->LowerLim) * d->M;
	 //  n = 1 + (int)floor(T);  /* n 1 too high when @t is an integer! */
         n = (int)ceil(T);  /* 23 Feb 2013 */
         break;
         }
      if (n <= C16) d->counts16[n-1] += 1;
      else d->counts8[n-FIRST_8BIT_BIN] += 1;
      }
   }

double bin_edge(struct distribution *d, int bin) {
   switch (d->Transform) {
   case DS_LIN_DIF:
   case DS_LIN:
      return d->LowerLim + bin*d->step;
      break;
   case DS_LOG_DIF:
   case DS_LOG:
      return d->LowerLim * pow(10.0, bin*d->step);
      break;
      }
   return 0;  /* Keep compiler happy */
   }

#define get_count(j) \
   if (j == 0) count = d->bin0_count; \
   else if (j <= C16) count = d->counts16[j-1]; \
   else count = d->counts8[j-FIRST_8BIT_BIN];

int compute_distrib_stats(struct source *sp) {
   int j, m_bin, mode,  nz,  cl,cr, count;
   double lifetime;
   struct distribution *d = sp->d.si->fi->d;

   mode = m_bin = nz = nz_runs = 0;
   for (j = 0; j != MXBUCKETS+1; ++j) {
      get_count(j);
      if (count > mode) {
	 m_bin = j;  mode = count;
         }
      if (count == 0) nz += 1;
      else if (nz != 0) {
	 if (nz > 1) nz_runs += 1;  /* Need two or more in a run */
         nz = 0;
         }
      }
   if (nz > 1) nz_runs += 1;  /* Run at top? */
   for (cl = 0, j = 0; j < m_bin-1; ++j) {
      get_count(j);  cl += count;
      }
   for (cr = 0, j = m_bin+2; j <= MXBUCKETS; ++j) {
      get_count(j);  cr += count;
      }
   b0pc = d->bin0_count*100.0/(d->total_count-1);
      /* -1 because first pkt not an IAT */
   modeiat = bin_edge(d, m_bin+1);
   if (m_bin > 0) {
      get_count(m_bin-1);  mode += count;
      }
   if (m_bin < MXBUCKETS-1) {
      get_count(m_bin+1);  mode += count;
      }
   skew = cr+cl == 0 ? 0.0 :(cr-cl)*100.0/(cl+cr);

   lifetime = sp->d.si->last_s - sp->d.si->first_s;  /* Determine IAT group */
   if (sp->totp < MXBUCKETS) {
          /* Too few pkts for reliable distribution stats */
      if (lifetime > 1800) {  /* long-lived */
	 if (modeiat > 3.0 && modeiat <= 4.0)
	    return IAT_stealth_3s_mode;
	 if (nz_runs <= 4) return IAT_stealth_spikes;
	 return IAT_stealth;
         }
      return IAT_short_lived;
      }
   else {
      if (sp->totp/lifetime > 5.0)  /* pkt/s */
	 return IAT_high_rate;
      if (b0pc > 10) return IAT_DOS;
      if (modeiat > 3.0 && modeiat <= 4.0) {
	 if (skew <= -10.0) return IAT_3_left;
         if (skew <= 10.0) return IAT_3_even;
	 return IAT_3_right;
         }
      }
   return IAT_Other;
   }

char key_s[150];  /* (Global) return value for key_to_s() */
char *key_to_s(struct source *sp) {
   if (sp->version == 4) {
      uint8_t *a = sp->src_addr.a.a;
      sprintf(key_s, "%u.%u.%u.%u", a[0],a[1],a[2],a[3]);
      }
   else if (sp->version == 6) {
      char *kp = v6addr_to_s(key_s, &sp->src_addr);
      kp[1] = '\0';
      }
   else {
      quack(999);
      log_msg(user_data, LOG_ERR, 2,
          "Tried to print key_type %d <<<", sp->version);
       }
   return key_s;
   }

void write_distrib_info(FILE *f, struct source *sp, struct distribution *d)
{
   fprintf(f, "#endtime: %s (UTC)\n", fmt_time(last_ts));
   fprintf(f, "#meter: %s\n", iat_meter_loc);
   fprintf(f, "#distrib: Transform=%u, Lower=%.3f, Upper=%.3f, Buckets=%u\n",
       d->Transform, d->LowerLim, d->UpperLim, d->Buckets);
   fprintf(f, "#title: inter-arrival time (s) " \
      "distribs for each one-way source\n");

#if 0  //BURST_STATS
   fprintf(f, "#   src, src_type,  pkt_av_len, sp->d.si->totp," \
      " d->n_bursts, d->min_burst_pkts, d->max_burst_pkts\n#\n");
#endif
   fprintf(f, "#attributes: src src_type  pktavlen totpkts" \
      "  ttlmode ttl2nd  portmode port2nd  flags keys  uT_count cfc_count" \
      "  first_s last_s  b0pc modeiat skew nzruns \n");
   fprintf(f, "#\n");
   }


static char saddr[150];  /* (Global) return value for src_addr_s() */
char *src_addr_s(struct source *sp) {
  if (sp->version == 4) {
    uint8_t *a = sp->src_addr.a.a;
    sprintf(saddr, "%u.%u.%u.%u", a[0],a[1],a[2],a[3]);
  }
  else if (sp->version == 6) {
    char *kp = v6addr_to_s(saddr, &sp->src_addr);
    kp[1] = '\0';
  }
  else {
    quack(999);
    log_msg(user_data, LOG_ERR, 2,
	    "Tried to print key_type %d <<<", sp->version);
  }
  return saddr;
}

int n_sources_written;
#if SOURCETIMEOUTS
int deleted_inactive;
void delete_source(struct source *sp) {
   sp->state = SS_DELETE;  /* Let watcher time it out */
   sp->d.si->timeout = STO_ONE_WAY;
   }
#endif

int update_source_attribs(struct source *sp) {
#if ERF_DIRECTION
   update_direction_counts(sp);
#endif

   if (sp->state == SS_DELETE) return 0;

#if OWS_STATS
   if (sp->state == SS_WAS_TWO_WAY || sp->state == SS_NEW_ONE_WAY) {
      stat_printf(user_data, "%d  %u  %u %u  %.3f  %.3f  %.3f   %d  %s", 
         sp->state, sp->totp, sp->d.si->tp, sp->d.si->fp,  /* tp = !local->local */
         sp->d.si->last_s - sp->d.si->first_s,
         sp->d.si->first_s, sp->d.si->last_s,
         sp->d.si->fi->tn_proto.values[0], key_to_s(sp));
      stat_printf(user_data, "   %u  %u %u  %.3g",
	 sp->d.si->ototp, sp->d.si->otp, sp->d.si->ofp, sp->d.si->orate);
      }
#endif

#if SOURCETIMEOUTS
   if (sp->d.si->active_since_last_sum == 0) {  /* Inactive this interval */
      if (sp->d.si->inactive_last_sum == 1) {
         delete_source(sp);  /* Inactive at least one whole #Record interval */
         deleted_inactive += 1;
         return 0;
         }
      sp->d.si->inactive_last_sum = 1;  /* Inactive at last #Record */
      return 0;
      }
   sp->d.si->inactive_last_sum = 0;  /* Active this interval */
   sp->d.si->active_since_last_sum = 0;
#endif

   if (sp->state != SS_ONE_WAY) {
      update_summary_info(sp);
      sp->d.si->tp = sp->d.si->fp = 0;  sp->d.si->tb = sp->d.si->fb = 0;
      return 0; 
      }
   if (sp->version == 4) {
      v4_one_way_sources += 1;
      v4_one_way_pkts += sp->d.si->tp;  v4_one_way_bytes += sp->d.si->tb;
      }
   else {
      v6_one_way_sources += 1;
      v6_one_way_pkts += sp->d.si->tp;  v6_one_way_bytes += sp->d.si->tb;
      }

   if (sp->d.si->fi == NULL) {  /* No flow_info */
      update_ua_stats(sp);  /* Un-analysed source info */
      return 0;  /* No flow_info (or distrib) struct */
      }
   return 1;  /* No problems */
   }

int init_distrib_set(struct distribution **dset, int nd,
      double lower, double upper, int bins, int transform) {
  int k;
   for (k = 0; k != nd; ++k) {
      dset[k] = get_distribution();
      if (dset[k] == NULL) return 0;
      init_distrib(dset[k], lower, upper, bins, transform);      
      }
   return 1;
   }      

#define SZ_sum32  70
topn_t(sum32, SZ_sum32, uint32_t);

void count_sum32(uint32_t p, struct topn_sum32 *tnp) {
   uint32_t j;
   for (j = 0; j != tnp->nv; j += 1) {
      if (p == tnp->values[j]) {
	 tnp->counts[j] += 1;  return;
	 }
      }
   if (j != SZ_sum32) {
      tnp->values[j] = p;  tnp->counts[j] = 1;
      tnp->nv += 1;
      }
   }

struct sum32_kv { uint32_t key, count; };

int sum32_compare(const void *pa, const void *pb) {
   const struct sum32_kv *a = pa, *b = pb;
   if (a->count < b->count) return +1;  /* Descending count order */
   if (a->count > b->count) return -1;
   return 0;
   }

int tops_sum32(char *kvs, int sz_kvs,
	       int n, struct topn_sum32 *tnp, int hex) {
  struct sum32_kv kv[SZ_sum32];
  int k, nr,  r, x;
  for (k = 0;  k != SZ_sum32; ++k) {
    kv[k].key = tnp->values[k];  kv[k].count = tnp->counts[k];
  }
  qsort(kv, tnp->nv, sizeof(struct sum32_kv), sum32_compare);
  nr = tnp->nv < n ? tnp->nv : n;
  if (nr == 0) kvs[0] = '\0';
  else {
    for (x = k = 0;  k != nr; ) {
      r = snprintf(&kvs[x], sz_kvs-x, hex ? "  %08x %u" : "  %u %u",
		   kv[k].key, kv[k].count);
      if (r > sz_kvs-x) {
	quack(666);
	strcpy(&kvs[x], "<<<< msg size too small <<<<");
	break;
      }
      x += r;  k += 1;
    }
  }
  return nr;
}

int top_cc_hashtable(char *kvs, int sz_kvs,
		     int n, struct hashtable *h, int hex) {
  struct key_val *kv;  int nr, k, r, x;
  kv = get_kv(h, &nr);  /* Finished with ht, destroys it */

  if (nr == 0)  kvs[0] = '\0';
  else {
    if (n < nr) nr = n;
    for (x = k = 0;  k != nr; ) {
      r = snprintf(&kvs[x], sz_kvs-x, hex ? "  %08x %u" : "  %u %u",
		   kv[k].key, kv[k].count);
      if (r > sz_kvs-x) {
	quack(777);
	strcpy(&kvs[x], "<<<< msg size too small <<<<");
	break;
      }
      x += r;  k += 1;
    }
    free(kv);
  }
  return nr;
}

#if HALF_WAY_SOURCES
int addr_cc_hashtable(char *kvs, int sz_kvs, int n, struct hashtable *h) {
  struct addr_key_val *kv;  int nr, k, r, x;
  uint8_t *a;
  kv = addr_get_kv(h, &nr);  /* Finished with ht, destroys it */
  if (nr == 0)  kvs[0] = '\0';
  else {
    if (n < nr) nr = n;
    for (x = k = 0;  k != nr; ) {
      a = kv[k].key.a.a;
      r = snprintf(&kvs[x], sz_kvs-x, "  %u.%u.%u.%u %u",
		   a[0],a[1],a[2],a[3], kv[k].count);
      if (r > sz_kvs-x) {
	quack(555);
	strcpy(&kvs[x], "<<<< msg size too small <<<<");
	break;
      }
      x += r;  k += 1;
    }
    free(kv);
  }
  return nr;
}
#endif

double r_start_ts;
int *s_count[N_source_types],  /* x N_source_groups */
   *s_pkt[N_source_types];
uint64_t *s_B[N_source_types];
struct distribution
   *d4_pkt[N_source_types], *d4_byte[N_source_types],
   *d4_life[N_source_types], *d4_rate[N_source_types],
   *d4_gpkt[N_source_groups], *d4_gbyte[N_source_groups],
   *d4_glife[N_source_groups], *d4_grate[N_source_groups],
   *d6_pkt[N_source_types], *d6_byte[N_source_types],
   *d6_life[N_source_types], *d6_rate[N_source_types],
   *d6_gpkt[N_source_groups], *d6_gbyte[N_source_groups],
   *d6_glife[N_source_groups], *d6_grate[N_source_groups];

struct sum_hts {
   struct topn_sum32 ip4_proto, ip6_proto,
      t4probe_ports, u4probe_ports, t4hscan_ports, u4hscan_ports,
      t445_len, t445_key, tcfc_len, tcfc_key,
      t6probe_ports, u6probe_ports, t6hscan_ports, u6hscan_ports,
      v6_addrs_top32;
   uint32_t t445_ttl[256], tcfc_ttl[256];   
   };
struct sum_hts *sht;

void write_counts_256(uint32_t *ca, int sz, const char *label) {
   char msg[500];  int j, mx;
   mx = sprintf(msg, "%s ", label);
   for (j = 0; j != sz; ++j) {
      if (mx+50 > sizeof(msg)) {
         quack(888);
         strcpy(&msg[mx], "<<<< msg size too small <<<<");
         break;
         }
      mx += sprintf(&msg[mx], " %u", ca[j]);
      if (j % 64 == 63) {
	 sum_printf(user_data, msg);  mx = 0;
         }
      }
   if (j % 64 != 0) sum_printf(user_data, msg);  /* print last line */
   }

int get_summary_space(void) {
  int k, r;
   for (k = 0; k != N_source_types; ++k ) {
      s_count[k] = (int *)calloc(N_source_groups, sizeof(int));
      if (s_count[k] == NULL) return 0;
      s_pkt[k] = (int *)calloc(N_source_groups, sizeof(int));
      if (s_pkt[k] == NULL) return 0;
      s_B[k] = (uint64_t *)calloc(N_source_groups, sizeof(uint64_t));
      if (s_B[k] == NULL) return 0;
      }
   r = init_distrib_set(d4_pkt,  N_source_types, 1, 5000, 100, DS_LOG);
   if (!r) return 0;
   r = init_distrib_set(d4_byte, N_source_types, 1000, 2000000, 120, DS_LOG);
   if (!r) return 0;
   r = init_distrib_set(d4_life, N_source_types, 1.0, mx_life, 120, DS_LOG);
   if (!r) return 0;
   r = init_distrib_set(d4_rate, N_source_types, 0.001, 1000.0, 100, DS_LOG);
   if (!r) return 0;
   r = init_distrib_set(d4_gpkt,  N_source_groups, 1, 5000, 100, DS_LOG);
   if (!r) return 0;
   r = init_distrib_set(d4_gbyte, N_source_groups, 1000, 2000000, 120, DS_LOG);
   if (!r) return 0;
   r = init_distrib_set(d4_glife, N_source_groups, 1.0, mx_life, 120, DS_LOG);
   if (!r) return 0;
   r =init_distrib_set(d4_grate, N_source_groups, 0.001, 1000.0, 100, DS_LOG);
   if (!r) return 0;
   if (local_v6) {
      r = init_distrib_set(d6_pkt,  N_source_types, 1, 5000, 100, DS_LOG);
      if (!r) return 0;
      r = init_distrib_set(d6_byte, N_source_types, 1000, 2000000, 120, DS_LOG);
      if (!r) return 0;
      r = init_distrib_set(d6_life, N_source_types, 1.0, mx_life, 120, DS_LOG);
      if (!r) return 0;
      r = init_distrib_set(d6_rate, N_source_types, 0.001, 1000.0, 100, DS_LOG);
      if (!r) return 0;
      r = init_distrib_set(d6_gpkt,  N_source_groups, 1, 5000, 100, DS_LOG);
      if (!r) return 0;
      r = init_distrib_set(d6_gbyte, N_source_groups, 1000, 2000000,
         120, DS_LOG);
      if (!r) return 0;
      r = init_distrib_set(d6_glife, N_source_groups, 1.0, mx_life,
         120, DS_LOG);
      if (!r) return 0;
      r =init_distrib_set(d6_grate, N_source_groups, 0.001, 1000.0,
         100, DS_LOG);
      if (!r) return 0;
      }
   sht = calloc(1, sizeof(struct sum_hts));
   if (sht == NULL) return 0;
   return 1;
   }

void free_summary_space(void) {
   int k;
   for (k = 0; k != N_source_types; ++k ) {
      free(s_count[k]);  s_count[k] = NULL;
      free(s_pkt[k]);  s_pkt[k] = NULL;
      free(s_B[k]);  s_B[k] = NULL;
      free(d4_pkt[k]);  d4_pkt[k] = NULL;
      free(d4_byte[k]);  d4_byte[k] = NULL;
      free(d4_life[k]);  d4_life[k] = NULL;
      free(d4_rate[k]);  d4_rate[k] = NULL;
      if (local_v6) {
         free(d6_pkt[k]);  d6_pkt[k] = NULL;
         free(d6_byte[k]);  d6_byte[k] = NULL;
         free(d6_life[k]);  d6_life[k] = NULL;
         free(d6_rate[k]);  d6_rate[k] = NULL;
         }
      }
  for (k = 0; k != N_source_groups; ++k ) {
      free(d4_gpkt[k]);  d4_gpkt[k] = NULL;
      free(d4_gbyte[k]);  d4_gbyte[k] = NULL;
      free(d4_glife[k]);  d4_glife[k] = NULL;
      free(d4_grate[k]);  d4_grate[k] = NULL;
      if (local_v6) {
         free(d6_gpkt[k]);  d6_gpkt[k] = NULL;
         free(d6_gbyte[k]);  d6_gbyte[k] = NULL;
         free(d6_glife[k]);  d6_glife[k] = NULL;
         free(d6_grate[k]);  d6_grate[k] = NULL;
         }
      }
   free(sht);
   }

int write_source_attribs(struct source *sp) {
     /* Return 0 to continue, 1 to stop walking */
   struct flow_info *fi;
   int src_type, src_group, proto_mode, proto_2nd,
      port_mode, port_2nd, uT_count, cfc_count;
   double life, rate;
   uint32_t v6_addr_32;
#if NON_CONF_TEST
   double ab_dest_pc;
#endif
   if (!update_source_attribs(sp)) return 0;
   if (sp->d.si == NULL) return 0;
   fi = sp->d.si->fi;
   if (sp->d.si->last_s-sp->d.si->first_s < MIN_LIFETIME)
      return 0;  /* Too short for sensible statistics */
   pkts_to_ob += sp->d.si->tp;

   src_type = analyse_flow(sp);  /* Sets probe_port globals */
   if (old_dbs) old_dns[src_type] += 1;  //old_dns
   if (fi->d != NULL)
      src_group = compute_distrib_stats(sp);
   else src_group = 0;

   if (sources_printf == NULL) {
      s_count[src_type][src_group] += 1;
      s_pkt[src_type][src_group] += sp->d.si->tp;
      s_B[src_type][src_group] += sp->d.si->tb;

#if NON_CONF_TEST
      if (src_type == S_conficker_c) {
 	 ab_dest_pc = sp->d.si->ab_dest*100.0/sp->d.si->tp;
         if (ab_dest_pc >= 100.0-CFC_EPSILON_PC)  /* Most pkts A/B */
            s_count[S_tcfc_dest_cfab][src_group] += 1;	    
	 else if (ab_dest_pc >= 25.0-CFC_EPSILON_PC
               && ab_dest_pc <= 25.0+CFC_EPSILON_PC)
            s_count[S_tcfc_dest_random][src_group] += 1;	    
	 else s_count[S_tcfc_dest_other][src_group] += 1;	    
         }
#endif

      if (sp->version == 4) {
         life = sp->d.si->last_s - sp->d.si->first_s;
         rate = sp->d.si->tp == 1 ? 0.0 : (sp->d.si->tp - 1)/life;
         bump_dist(d4_pkt[src_type], sp->d.si->tp);
         bump_dist(d4_byte[src_type], sp->d.si->tb);
         bump_dist(d4_life[src_type], life);
         bump_dist(d4_rate[src_type], rate);
         bump_dist(d4_gpkt[src_group], sp->d.si->tp);
         bump_dist(d4_gbyte[src_group], sp->d.si->tb);
         bump_dist(d4_glife[src_group], life);
         bump_dist(d4_grate[src_group], rate);
         count_sum32(protocol, &sht->ip4_proto);
         if (probe_port_valid) {
	    switch (src_type) {
            case S_tcp_probe:
               count_sum32(probe_port, &sht->t4probe_ports);
	       break;
            case S_udp_probe:
               count_sum32(probe_port, &sht->u4probe_ports);
	       break;
            case S_tcp_horizontal_scan:
               count_sum32(probe_port, &sht->t4hscan_ports);
	       break;
            case S_udp_horizontal_scan:
               count_sum32(probe_port ,&sht->u4hscan_ports);
	       break;
#if NON_CONF_TEST
            case S_t445_dest_cfab:
            case S_t445_dest_random:
            case S_t445_dest_other:
#else
            case S_tcp_445_horiz_scan:
#endif
               count_sum32(probe_port, &sht->t4probe_ports);
   	       count_sum32(iplen_mode, &sht->t445_len);
   	       count_sum32(keys_mode, &sht->t445_key);
	       sht->t445_ttl[ttl_mode] += 1;
	       break;
	       }
	    }
         if (src_type == S_conficker_c && protocol == PT_TCP) {
     	    count_sum32(iplen_mode, &sht->tcfc_len);
   	    count_sum32(keys_mode, &sht->tcfc_key);
	    sht->tcfc_ttl[ttl_mode] += 1;
	    }
         }
      else  if (local_v6) {
         life = sp->d.si->last_s - sp->d.si->first_s;
         rate = sp->d.si->tp == 1 ? 0.0 : (sp->d.si->tp - 1)/life;
         bump_dist(d6_pkt[src_type], sp->d.si->tp);
         bump_dist(d6_byte[src_type], sp->d.si->tb);
         bump_dist(d6_life[src_type], life);
         bump_dist(d6_rate[src_type], rate);
         bump_dist(d6_gpkt[src_group], sp->d.si->tp);
         bump_dist(d6_gbyte[src_group], sp->d.si->tb);
         bump_dist(d6_glife[src_group], life);
         bump_dist(d6_grate[src_group], rate);
         count_sum32(protocol, &sht->ip6_proto);
         if (probe_port_valid) {
	    switch (src_type) {
            case S_tcp_probe:
               count_sum32(probe_port, &sht->t6probe_ports);
	       break;
            case S_udp_probe:
               count_sum32(probe_port, &sht->u6probe_ports);
	       break;
            case S_tcp_horizontal_scan:
               count_sum32(probe_port, &sht->t6hscan_ports);
	       break;
            case S_udp_horizontal_scan:
               count_sum32(probe_port ,&sht->u6hscan_ports);
	       break;
   	       }           
 	    }
         v6_addr_32 = htonl(top_addrs6(&fi->v.v6.tn_dst_addrs));
         count_sum32(v6_addr_32, &sht->v6_addrs_top32);
         }
      }
   else {  /* Dummp info about sources */
      uT_count = fi->uT_count;  cfc_count = fi->cfc_count;
      switch (protocol) {
      case PT_TCP:  
         port_mode = top2_uint16(&fi->tn_tcp, &port_2nd);
         break;
      case PT_UDP:
         port_mode = top2_uint16(&fi->tn_udp, &port_2nd);
         break;
      default:
         port_mode = port_2nd = -1;
         }
      proto_mode = top2_uint8(&fi->tn_proto, &proto_2nd);

      sources_printf(user_data,
         "%d %d  %08x %s %"PRIu64" %u %d  %d %d %d %02x %08x  %d %d"
            "  %.3f %.3f  %.2f %.2f %.2f %d", 
         src_type, src_group, htonl(sp->src_addr.a.v4), key_to_s(sp),
         (sp->d.si->tb/sp->d.si->tp), sp->totp, ttl_mode,
         proto_mode, proto_2nd, port_mode, flags_mode, keys_mode,
         uT_count, cfc_count,
         sp->d.si->first_s-r_start_ts, sp->d.si->last_s-r_start_ts,
         b0pc, modeiat, skew, nz_runs);

      }
   sp->d.si->tp = 0;  sp->d.si->tb = 0;  /* Reset pkt counts */
   return 0;
   }

void write_int_matrix(int version, const char *section_head,
      int **m, const char *fmt) {
   int r, c, x;  char line[150];
   sum_printf(user_data, "#%d%s", version, section_head);
   for (r = 0; r != N_source_types; ++r) {
      for (x = c = 0; c != N_source_groups; ++c)
         x += sprintf(&line[x], fmt, m[r][c]);
      sum_printf(user_data, line);
      }
   sum_printf(user_data, "");  /* Blank line */
   }

void write_MB_matrix(int version, const char *section_head,
      uint64_t **m, const char *fmt) {
   int r, c, x;  char line[150];
   sum_printf(user_data, "#%d%s", version, section_head);
   for (r = 0; r != N_source_types; ++r) {
      for (x = c = 0; c != N_source_groups; ++c)
         x += sprintf(&line[x], fmt, m[r][c]/1000000.0);
      sum_printf(user_data, line);
      }
   sum_printf(user_data, "");  /* Blank line */
   }

void write_distrib_set(int version, const char *section_head,
      const char *unit, struct distribution **dset, int nd,
      const char *fmt) {
   char *line;  int j, x, r, count, mx_x;
   struct distribution *d;
#define LINE_SZ  1500
   sum_printf(user_data, "#%d%s", version, section_head);
   d = dset[0];
   line = malloc(LINE_SZ);
   if (!line) {
      log_msg(user_data, LOG_WARNING, 0,
         "write_distrib_set() couldn't get line buffer!");
      return;
      }
   for (x = j = 0; j <= d->Buckets; ++j)
     x += sprintf(&line[x], fmt, bin_edge(dset[0], j));
   sum_printf(user_data, "%s %s", unit, line);
   mx_x = x;
   for (r = 0; r != nd; ++r) {
      d = dset[r];
      for (x = j = 0; j <= d->Buckets; ++j) {
 	 get_count(j);
	 if (x+40 > LINE_SZ) {
            quack(444);
	    strcpy(&line[x], "<<<< msg size too small <<<<");
            break;
	    }
         x += sprintf(&line[x], " %d", count);
         }
      sum_printf(user_data, "%d %s", r, line);
      if (x > mx_x) mx_x = x;
      }
   sum_printf(user_data, "");  /* Blank line */
   if (mx_x > LINE_SZ) log_msg(user_data, LOG_ERR, 1, 
      "write_distrib_set: mx_x = %d, i.e. > %d\n", mx_x, LINE_SZ);
   free(line);
   }

void write_vn_info(int v) {
   int n;  char msg[1200];
   write_int_matrix(v, "msrc (Source Counts)", s_count, " %12d");
   write_int_matrix(v, "mpkt (Source Packets)", s_pkt, " %12d");
   write_MB_matrix(v, "mmbyte (Source Volume)", s_B, " %12.6f");
 
   write_distrib_set(v, "dpkt (Type Packets)",
     "p", v == 4 ? d4_pkt : d6_pkt, N_source_types, " %.1f");
   write_distrib_set(v, "dbyte (Type Volume)",
      "B", v == 4 ? d4_byte : d6_byte, N_source_types, " %.1f");
   write_distrib_set(v, "dlife (Type Lifetimes)",
      "s", v == 4 ? d4_life : d6_life, N_source_types, " %.4f");
   write_distrib_set(v, "drate (Type Rate)",
      "p/s", v == 4 ? d4_rate : d6_rate, N_source_types, " %.4f");
   write_distrib_set(v, "dpkt (Group Packets)",
      "p", v == 4 ? d4_gpkt : d6_gpkt, N_source_groups, " %.1f");
   write_distrib_set(v, "dbyte (Group Volume)",
      "B", v == 4 ? d4_gbyte : d6_gbyte, N_source_groups, " %.1f");
   write_distrib_set(v, "dlife (Group Lifetimes)",
      "s", v == 4 ? d4_glife : d6_glife, N_source_groups, " %.4f");
   write_distrib_set(v, "drate (Group Rate)",
      "p/s", v == 4? d4_grate : d6_glife, N_source_groups, " %.4f");
#define SZ_sum_ports  50
   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports, 
      v == 4 ? &sht->t4probe_ports : &sht->t6probe_ports, 0);
   sum_printf(user_data, "#%dtprobe_ports\n%d%s\n", v, n, msg);
   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports,
      v == 4 ?&sht->u4probe_ports : &sht->u6probe_ports, 0);
   sum_printf(user_data, "#%duprobe_ports\n%d%s\n", v, n, msg);
   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports, 
      v == 4 ? &sht->t4hscan_ports : &sht->t6hscan_ports, 0);
   sum_printf(user_data, "#%dhoriz_scan_ports\n%d%s\n", v, n, msg);
   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports,
      v == 4 ? &sht->u4hscan_ports : &sht->u6hscan_ports, 0);
   sum_printf(user_data, "#%duhoriz_scan_ports\n%d%s\n", v, n, msg);

   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports, &sht->t445_len, 0);
   sum_printf(user_data, "#%dt445_ip_lengths\n%d%s\n", v, n, msg);
   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports, &sht->t445_key, 1);
   sum_printf(user_data, "#%dt445_tcp_keys\n%d%s\n", v, n, msg);
   sum_printf(user_data, "#%dt445_ttls", v, n, msg);
   write_counts_256(sht->t445_ttl, 256, "sources");
   sum_printf(user_data, "");
    
   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports, &sht->tcfc_len, 0);
   sum_printf(user_data, "#%dtcfc_ip_lengths\n%d%s\n", v, n, msg);
   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports, &sht->tcfc_key, 1);
   sum_printf(user_data, "#%dtcfc_tcp_keys\n%d%s\n", v, n, msg);
   sum_printf(user_data, "#%dtcfc_ttls", v, n, msg);
   write_counts_256(sht->tcfc_ttl, 256, "sources");
   sum_printf(user_data, "");

   n = tops_sum32(msg, sizeof(msg), SZ_sum_ports, &sht->ip4_proto, 0);
   sum_printf(user_data, "#%dptotocols\n%d%s\n", v, n, msg);

   sum_printf(user_data, "#%dway_counts (S/p//B for 1,2,0.5-way)", v);
   if (v == 4) {
      sprintf(&msg[0], "%"PRIu64" %"PRIu64" %"PRIu64,
         v4_one_way_sources, v4_one_way_pkts, v4_one_way_bytes);
#if SOURCETIMEOUTS
      sprintf(&msg[0], "%"PRIu64" %"PRIu64" %"PRIu64,
         v4_two_way_sources, v4_two_way_pkts, v4_two_way_bytes);
# if HALF_WAY_SOURCES
      sprintf(&msg[0], "%"PRIu64" %"PRIu64" %"PRIu64,
         v4_half_way_sources, v4_half_way_pkts, v4_half_way_bytes);
# endif
#endif
      sum_printf(user_data, msg);
      }
   else if (local_v6) {
      sprintf(&msg[0], "%"PRIu64" %"PRIu64" %"PRIu64,
        v6_one_way_sources, v6_one_way_pkts, v6_one_way_bytes);
#if SOURCETIMEOUTS
      sprintf(&msg[0], "%"PRIu64" %"PRIu64" %"PRIu64,
	v6_two_way_sources, v6_two_way_pkts, v6_two_way_bytes);
# if HALF_WAY_SOURCES
      sprintf(&msg[0], "%"PRIu64" %"PRIu64" %"PRIu64,
	v6_half_way_sources, v6_half_way_pkts, v6_half_way_bytes);
# endif
#endif
      sum_printf(user_data, msg);
      }
   sum_printf(user_data, "");
   }

void write_summary(int which) {
   struct flow_watcher_control *fw;
   struct source_queue *sq;
#define MX  50
   char fns[20], msg[1000+MX];  struct tm *start_tm;
   int k;  uint64_t unusable;

#if SOURCETIMEOUTS
   deleted_inactive = 0;
#endif

   if (sources_printf == NULL) {
      if (!get_summary_space()) log_msg(user_data, LOG_ERR, 1,
         "Couldn't get space for write_summary!");
      }
   else {  /* Write header info for sources info */
      n_sources_written = 0;
      sources_printf(user_data, "#trace: %s", iat_trace_name);
      sources_printf(user_data, "#starttime: %u = %s (UTC)",
         start_ts, fmt_time(start_ts));
      sources_printf(user_data, "#meter: %s", iat_meter_loc);
      sources_printf(user_data, "#attributes: type group  "
         "sa_hex src_addr av_pkt_len, tot_pkts, ttl  "
         "proto_mode proto_2nd port_mode flags_mode keys_mode  "
         "uTcount cfc_count  first_s last_s  bin0%% iat_mode skew nz_runs");
      }

   wait_for_recording_checks();  /* Sets ct_count = CV_RECORDING */
   for (k = 0;  k != N_source_types; ++k) old_dns[k] = 0;  //old_dns

   for (k = 0; k != n_flow_watchers; ++k) {  /* Record: processing */
      fw =fwa[k];  sq = &fw->sq;
      // printf("walking fw %d, length=%d\n", k, sq->length);
      source_walk_down(sq, write_source_attribs);
      }  /* Writes source-summary records if sources_printf == NULL
            otherwise writes info about sources using sources_printf() */

   if (sources_printf == NULL) {
      start_tm = gmtime(&start_tt);
      strftime(fns, sizeof(fns), "%Y%m%d.%H%M", start_tm);
      sum_printf(user_data, 
		 "#version\n2.2 "
#if IATMON
                 "iatmon"
#else
                 "smee"
#endif
		 " "IATversion"\n");
      if (live_source) strcpy(msg, node.nodename);
      else sprintf(msg, "%.3f", file_size(iat_trace_name)/1000000000.0); 
      sum_printf(user_data, "#meter_info\n%s %s %s %d %s\n",
	 iat_meter_loc, fns, msg,
         MIN_pkts_to_classify, SOURCETIMEOUTS ? "two-way" : "");

      write_counts_256(old_dns, N_source_types, "#old_dns");  //old_dns
      sum_printf(user_data, "");  //old_dns

      write_vn_info(4);
      if (local_v6) {
         write_vn_info(6);
         k = tops_sum32(msg, sizeof(msg), 20, &sht->v6_addrs_top32, 1);
         sum_printf(user_data, "#v6addrs (first 32 bits)\n%d%s\n", k, msg);
         }
      free_summary_space();

      if (n_unanalysed_sources != 0) {
         sum_printf(user_data, "#unanalysed  %u sources, %u pkts not analysed",
            n_unanalysed_sources, n_unanalysed_pkts);
         write_counts_256(ua_pkts, MN_PKTS_FOR_DISCARD, "pkts");
         write_counts_256(ua_src_addr, 256, "src_addr");
         write_counts_256(ua_ttl, 256, "ttl");
         write_counts_256(ua_proto, 256, "proto");
         write_counts_256(ua_dst_addr, 256, "dst_addr");
         if (ua_gt1prot != 0) {
	    sum_printf(user_data, "gt1prot %u", ua_gt1prot);
	    }
         if (ua_dst_ports != NULL) {
	    k = top_cc_hashtable(msg, sizeof(msg)-MX,
   	       SZ_sum_ports, ua_dst_ports, 0);
	    sum_printf(user_data, "dest_port  %d%s\n", k, msg);
	    }
         if (ua_tcp_keys != NULL) {
	    k = top_cc_hashtable(msg, sizeof(msg)-MX,
	       SZ_sum_ports, ua_tcp_keys, 1);
	    sum_printf(user_data, "tcp_key  %d%s\n\n", k, msg);
	    }
         n_unanalysed_sources = 0;  /* Ready for next report interval */
         }
#if HALF_WAY_SOURCES
      k = addr_cc_hashtable(msg, sizeof(msg)-MX, 20, half_src_addrs);
      sum_printf(user_data, "#half_way source addresses\n%d%s\n", k, msg);
#endif

#if ERF_DIRECTION
      k = sprintf(msg, "%"PRIu64" %"PRIu64" %"PRIu64"",
		  one_way_sources_1, one_way_sources_2, one_way_sources_3);
# if SOURCETIMEOUTS
      k += sprintf(&msg[k], "  %"PRIu64" %"PRIu64" %"PRIu64"",
		   two_way_sources_1, two_way_sources_2, two_way_sources_3);
# endif
# if HALF_WAY_SOURCES
      k += sprintf(&msg[k], "  %"PRIu64" %"PRIu64" %"PRIu64"",
		   half_way_sources_1, half_way_sources_2, half_way_sources_3);
# endif
      sum_printf(user_data,
		 "#erf_sources (1/2/3 for 1,2,0.5-way)\n%s\n", msg);
#endif

      unusable = t_no_local_address + t_frags + t_too_small +
         t_v6_opaque + t_not_ip;
      sum_printf(user_data, "#pktcounts\n"
            "pkts_read=%d, pkts_unusable=%d (%.2f%%);  "
	    "no_local_addr=%d, frags=%d, too_small=%d, v6opaque=%d, non-IP=%d",
	 pkts_from_trace, unusable, unusable*100.0/pkts_from_trace,
	 t_no_local_address, t_frags, t_too_small, t_v6_opaque, t_not_ip);
      sum_printf(user_data, "pkts_processed=%d, pkts_reported=%d (%.2f%%)\n",
	 pkts_at_flow_watchers, pkts_to_ob,
         pkts_to_ob*100.0/pkts_at_flow_watchers);
      reset_summary_info();  pkts_to_ob = 0;

#if SOURCETIMEOUTS
      sum_printf(user_data ,"#Sources: two=%llu  v4=%llu v6=%llu  inactive=%d",
         v4_two_way_sources+v6_two_way_sources,
         v4_one_way_sources, v6_one_way_sources,
         deleted_inactive);
#endif

      k = get_usage(&iu2);
      if (!k) log_msg(user_data, LOG_WARNING, 0,
         "write_sumary(): couldn't get usage info!");
      else if (iu1.mxrss > 0) {
         sum_printf(user_data, "#times (minutes): trace_duration=%.2f"
   	       " elapsed=%.2f user=%.2f system=%.2f"
               "  max_rss=%.3f GB\n\n#eof",
  	    (last_ts-start_ts)/60.0, (iu2.tod-iu1.tod)/60.0,
	    (iu2.tuser-iu1.tuser)/60.0, (iu2.tsystem-iu1.tsystem)/60.0,
	    iu2.mxrss);
         }
      memcpy(&iu1, &iu2, sizeof(struct iat_usage));  start_ts = last_ts;
      }
   pthread_mutex_lock(&count_mutex);
   ct_count += 1;  /* Set count = CV_IDLE */
   pthread_mutex_unlock(&count_mutex);
   }


uint32_t n_unanalysed_sources, n_unanalysed_pkts;
uint32_t    /* Stats for unanalysed sources */
   ua_pkts[MN_PKTS_FOR_DISCARD],  /* Nbr of packets */
   ua_src_addr[256],  /* Source addresses */
   ua_dst_addr[256],  /* Dest addresses */
   ua_ttl[256],       /* TTLs */
   ua_proto[256],     /* Protocols */
   ua_gt1prot;        /* More than one proto seen */
struct hashtable *ua_dst_ports, *ua_tcp_keys;

void init_ua_variables(void) {
   printf("init_ua_variables(): n_unanalysed_sources = %d, n_unanalysed_pkts = %d\n",
      n_unanalysed_sources, n_unanalysed_pkts);  //UN                        
   fflush(stdout);  //UN                                                     
   ua_gt1prot = n_unanalysed_sources = n_unanalysed_pkts = 0;

   memset(ua_pkts, 0, MN_PKTS_FOR_DISCARD*sizeof(uint32_t));
   memset(ua_src_addr, 0, 256*sizeof(uint32_t));
   memset(ua_dst_addr, 0, 256*sizeof(uint32_t));
   memset(ua_ttl, 0, 256*sizeof(uint32_t));
   memset(ua_proto, 0, 256*sizeof(uint32_t));

   ua_dst_ports = create_hashtable(5000, hashfromkey, equalkeys);
   ua_tcp_keys = create_hashtable(5000, hashfromkey, equalkeys);
   }

#define firstbyte(a)  ((ntohl(a) >> 24) & 0x000000FF)
#define secondbyte(a) ((ntohl(a) >> 16) & 0x000000FF)

void update_ua_stats(struct source *sp) {
   int port = -1, ttl;
   struct flow_info *fi;

   if (n_unanalysed_sources == 0) init_ua_variables();
   n_unanalysed_sources += 1;  n_unanalysed_pkts += sp->totp;

   if (sp->d.si->tp == 0) return;
      /* Only seen 'from' pkts so far.  Thu, 1 Dec 11 */
   if (sp->d.si->tp > MN_PKTS_FOR_DISCARD)  /* Don't stop!  Tue, 22 Nov 11 */
      log_msg(user_data, LOG_WARNING, 0,
         "update_ua_stats(): tp = %d (too big)", sp->d.si->tb);
   else ua_pkts[sp->d.si->tp-1] += 1;
   ua_src_addr[firstbyte(sp->src_addr.a.v4)] += 1;
   if (sp->d.si->fi != NULL) {
      fi = sp->d.si->fi;
      ttl = top_uint8(&fi->tn_ttl);
      ua_ttl[ttl] += 1;
      if (sp->version == 4) {  /* Don't bother to count v6 ua flows */
         if (fi->v.v4.tn_dst_addrs.nv == 0)
	    log_msg(user_data, LOG_ERR, 0, "fi4->tn_dst_addrs.nv == 0\n");
         ua_dst_addr[secondbyte(top_addrs4(&fi->v.v4.tn_dst_addrs))] += 1;
         ua_proto[top_uint8(&fi->tn_proto)] += 1;
         if (fi->tn_proto.nv == 1) {
	    if (fi->tn_proto.values[0] == PT_TCP) {
	       port = top_uint16(&fi->tn_tcp);
	       }
	    if (fi->tn_proto.values[0] == PT_UDP) {
	       port = top_uint16(&fi->tn_udp); 
	       }
	    }
	 else ua_gt1prot += 1;
         }
      if (fi->tcp_key != 0)
         iat_ht_insert(ua_tcp_keys, fi->tcp_key); 
      }

   if (port >= 0) iat_ht_insert(ua_dst_ports, port);
   }

/* We're using Christopher Clark's hashtable routines
      (by Christopher Clark, https://github.com/davidar/c-hashtable) */

struct value { int count; };  /* All our tables use uint32_t count as value */

#if HALF_WAY_SOURCES
/* Hash table routines for ports and tcp_keys .. */

DEFINE_HASHTABLE_INSERT(insert_some_addr, struct ip_address, struct value);
DEFINE_HASHTABLE_SEARCH(search_some_addr, struct ip_address, struct value);
DEFINE_HASHTABLE_REMOVE(remove_some_addr, struct ip_address, struct value);
DEFINE_HASHTABLE_ITERATOR_SEARCH(search_itr_some_addr, struct ip_address);

unsigned int hashfromaddr(void *ky) {
   struct ip_address *a = ky;
   if (a->ver == 4) {
     //      return sp->src_addr.a.v4 ^ (4 * 97171);
      return (a->a.v4 >> 9) + a->a.v4 * 5;
      }
   else {  /* v6 source */
      uint64_t hh = a->a.o.oct0 ^ a->a.o.oct1;
      return ((uint32_t *)&hh)[1] ^ ((uint32_t *)&hh)[0] ^ (6 * 96953);
      }
   }

int equaladdrs(void *ky1, void *ky2) {
   struct ip_address *a = ky1, *b = ky2;
   if (a->ver == 4) {
      return
	 a->a.v4 == b->a.v4 &&
         a->ver == b->ver;
      }
   else {  /* v6 source */
      return 
         a->a.o.oct1 == b->a.o.oct1 && a->a.o.oct0 == b->a.o.oct0 &&
         a->ver == b->ver;
      }

   }

void addr_ht_insert(struct hashtable *h, struct ip_address *addr) {
   struct value *v, *found;
   struct ip_address *k = (struct ip_address *)malloc(sizeof(struct ip_address));
   if (k == NULL)
      log_msg(user_data, LOG_ERR, 111,
         "Out of memory allocating an ip_address");
   memcpy(k, addr, sizeof(struct ip_address));

   if ((found = search_some_addr(h, addr)) == NULL) {  /* Not found */
      v = (struct value *)malloc(sizeof(struct value));
      if (v == NULL)
         log_msg(user_data, LOG_ERR, 222, "Out of memory allocating a value");
      v->count = 1;
      if (!insert_some_addr(h,k,v))
         log_msg(user_data, LOG_ERR, 333, "Out of memory inserting a key");
      }
   else found->count += 1;
   }

int addr_kv_cmp(const void *a, const void *b) {
   const struct addr_key_val *kva = a;
   const struct addr_key_val *kvb = b;
   if  (kvb->count > kva->count) return 1;
   else if (kvb->count == kva->count) return 0;
   return -1;
   }

struct addr_key_val *addr_get_kv( struct hashtable *h, int *length) {
   /* Return vector of (k,v) structs from ht, then destroy ht */
   struct hashtable_itr *itr = hashtable_iterator(h);
   int j, len = hashtable_count(h);
   struct addr_key *k;  struct value *v;
   struct addr_key_val *kv = NULL;

   *length = len;
   if (len > 0) {
      kv = (struct addr_key_val *)malloc(len*sizeof(struct addr_key_val));
      if (kv != NULL) {
         j = 0;  do {
	    k = hashtable_iterator_key(itr);
	    v = hashtable_iterator_value(itr);
 	    kv[j].key = k->key;  kv[j].count = v->count;
	    j += 1;
            } while (hashtable_iterator_advance(itr));
         }
      qsort(kv, len, sizeof(struct addr_key_val), addr_kv_cmp);
      }
   free(itr);
   hashtable_destroy(h,1); /* Second arg says "free(value)" */
 
   return kv;
   }
#endif

/* Hash table routines for ports and tcp_keys .. */

DEFINE_HASHTABLE_INSERT(insert_some, struct key, struct value);
DEFINE_HASHTABLE_SEARCH(search_some, struct key, struct value);
DEFINE_HASHTABLE_REMOVE(remove_some, struct key, struct value);
DEFINE_HASHTABLE_ITERATOR_SEARCH(search_itr_some, struct key);

unsigned int hashfromkey(void *ky) {
   struct key *k = (struct key *)ky;
   return (k->key >> 9) + k->key * 5; 
   } 

int equalkeys(void *ky1, void *ky2) {
   struct key *k1 = (struct key *)ky1,
      *k2 = (struct key *)ky2;
   return (k1->key == k2->key);
   }

void iat_ht_insert(struct hashtable *h, uint32_t tk) {
   struct value *v, *found;
   struct key *k = (struct key *)malloc(sizeof(struct key));
   if (k == NULL)
      log_msg(user_data, LOG_ERR, 111, "Out of memory allocating a key");
   k->key = tk;

   if ((found = search_some(h,k)) == NULL) {  /* Not found */
      v = (struct value *)malloc(sizeof(struct value));
      if (v == NULL)
         log_msg(user_data, LOG_ERR, 222, "Out of memory allocating a value");
      v->count = 1;
      if (!insert_some(h,k,v))
         log_msg(user_data, LOG_ERR, 333, "Out of memory allocating a key");
      }
   else found->count += 1;
   }

int kv_cmp(const void *a, const void *b) {
   const struct key_val *kva = a;
   const struct key_val *kvb = b;
   if  (kvb->count > kva->count) return 1;
   else if (kvb->count == kva->count) return 0;
   return -1;
   }

struct key_val *get_kv( struct hashtable *h, int *length) {
   /* Return vector of (k,v) structs from ht, then destroy ht */
   struct hashtable_itr *itr = hashtable_iterator(h);
   int j, len = hashtable_count(h);
   struct key *k;  struct value *v;
   struct key_val *kv = NULL;

   *length = len;
   if (len > 0) {
      kv = (struct key_val *)malloc(len*sizeof(struct key_val));
      if (kv != NULL) {
         j = 0;  do {
	    k = hashtable_iterator_key(itr);
	    v = hashtable_iterator_value(itr);
 	    kv[j].key = k->key;  kv[j].count = v->count;
	    j += 1;
            } while (hashtable_iterator_advance(itr));
         }
      qsort(kv, len, sizeof(struct key_val), kv_cmp);
      }
   free(itr);
   hashtable_destroy(h,1); /* Second arg says "free(value)" */
 
   return kv;
   }

/* ----- End of hash table routines ----- */


void init_mem(int mx_sources) {
   int mx_source_infos, mx_flow_infos;
   n_unanalysed_sources = 0;  /* Un-analysed source count */
   pkts_at_flow_watchers = 0, pkts_to_ob = 0;
   init_mutexes();

   pkts_from_trace = pkts_at_flow_watchers = pkts_to_ob = 0;
   t_not_ip = t_frags = t_too_small = t_no_local_address = 
      t_twolocaladdrs = t_v6_opaque = 0;

   memset(&event_q, 0, sizeof(struct event));
   event_q.type = NO_EVENT;
   event_mem_init(6);

#if SOURCETIMEOUTS
   mx_source_infos = mx_sources; /* was *8/10;  17 Jan 12 */
   if (mx_source_infos < 30000) mx_source_infos = 300000;
   mx_flow_infos = mx_source_infos/3;
#else
   mx_source_infos = mx_sources;
   mx_flow_infos = mx_sources;
#endif

   pkt_info_mem_init(DFMXPWQUEUESZ * DFMXFLOWWATCHERS);

   source_info_mem_init((MX_EXTRA_BLOCKS+1) * mx_source_infos);
   v4_flow_info_mem_init((MX_EXTRA_BLOCKS+1) * mx_flow_infos);
   v6_flow_info_mem_init((MX_EXTRA_BLOCKS+1) * mx_flow_infos/8);
   distribution_mem_init((MX_EXTRA_BLOCKS+1) * mx_flow_infos*9/8);

   source_mem_init((MX_EXTRA_BLOCKS+1) * mx_sources);

#if HALF_WAY_SOURCES
   half_src_addrs = NULL;
#endif
   }

char *iat_init(const char *trace_name,
      const char *c_meter_loc, int c_mx_life, int c_mx_sources,
      int c_time_rec_interval,
      struct ip_address *c_local_addrs, int c_n_local_addrs,
      void *c_user_data,
      void (*c_log_msg)(void *user_data, int priority, int die, 
         char const *fmt, ...),
      int (*c_stat_printf)(void *user_data, const char *fmt, ...),
      int (*c_sum_printf)(void *user_data, const char *fmt, ...),
      int (*c_sources_printf)(void *user_data, const char *fmt, ...),
      uint64_t (*c_pkt_drops)(void *user_data)) {
   char name[250];
   uint32_t ht_size, k;

   k = get_usage(&iu1);
   if (!k) log_msg(user_data, LOG_WARNING, 0,
      "iat_init(): couldn't get usage info!");
   user_data = c_user_data;
   log_msg = c_log_msg;  /* Use iat-control's log_msg() */
   stat_printf = c_stat_printf;
   sum_printf = c_sum_printf;
   sources_printf = c_sources_printf;

   pkt_drops = c_pkt_drops;  /* and pkt_drops() functions */

   iat_trace_name = trace_name;  iat_meter_loc = c_meter_loc;
   mx_life = c_mx_life;
   mx_sources = c_mx_sources;
#if 0  /* Tue, 5 Mar 13 (PST) */
   if (c_mx_source_types != N_source_types ||
         c_min_pkts_to_classify != MIN_pkts_to_classify)
      log_msg(user_data,LOG_WARNING, 0,
        "n_source_types or min_pkts_to_classify"
        " don't match values defined in iatmon !!!");
   n_source_types = c_mx_source_types;
   min_pkts_to_classify = c_min_pkts_to_classify;
#else
   n_source_types = N_source_types;  /* #defined with S_* in iat-smee.h */
   min_pkts_to_classify = MIN_pkts_to_classify;  /* ditto */
#endif
   time_rec_interval = c_time_rec_interval;
   n_local_addrs = c_n_local_addrs;
   if ((la = malloc(sizeof(struct ip_address)*c_n_local_addrs)) == NULL) {
      fprintf(stderr, "out of memory\n");  abort();
      }
   memcpy(la, c_local_addrs, (sizeof(struct ip_address)*c_n_local_addrs));
   for (local_v6 = k = 0;  k != n_local_addrs; ++k)
      if (la[k].ver == 6) local_v6 = 1;

#if STARTUP_DEBUG
   printf("entering iat_init() +-+\n");  fflush(stdout);
#endif
   sprintf(name, "One-Way Traffic Monitor v%s", IATversion);
   
#if MKSTATSCOUNTS
#define N_INTERVALS  (traces_to_process*STATS_INTERVALS_PER_HOUR +1)
   active_sources_per_stats_interval =  /* Allocate per-src_type rows */
      calloc(N_INTERVALS, sizeof(uint32_t *));
      /* +1 because we see a few packets recorded after the hour change! */
   unique_hosts_per_stats_interval =
      calloc(N_INTERVALS,  sizeof(uint32_t *));
   for (k = 0; k != N_INTERVALS; ++k) {
      /* Allocate per-minute rows */
      active_sources_per_stats_interval[k] =
         calloc(n_source_types, sizeof(uint32_t));
      unique_hosts_per_stats_interval[k] =
         calloc(n_source_types, sizeof(uint32_t *));
      }
   active_sources_this_interval = active_sources_per_stats_interval[0];
   unique_hosts_this_interval = unique_hosts_per_stats_interval[0];
   stats_interval_nbr = 1;  /* 1-org interval nbrs */
#endif
   n_unanalysed_sources = n_unanalysed_pkts = 0;
#if MKDESTCOUNTS
   dest_addrs_per_source_type = malloc(n_source_types*sizeof(uint32_t *));
   for (k = 0; k != n_source_types; ++k) {
      dest_addrs_per_source_type[k] = calloc(NDESTBINS, sizeof(uint32_t));
      }
#endif

   request_shutdown = ct_count = 0;

   init_mem(mx_sources);

   mx_active_sources = mx_active_source_infos =
      mx_active_v4_flow_infos = mx_active_v6_flow_infos =
      av_cl_count = n_hc_searches = 0;

   n_not_ip = n_frags = n_too_small = n_v6_opaque = n_no_local_address =
      intervals_this_sum_file = 0;

   pkts_this_second = av_pkt_count = mx_pkt_count = 0;
   reset_summary_info();

   n_flow_watchers = DFMXFLOWWATCHERS;
   ht_size = mx_sources*(MX_EXTRA_BLOCKS+1)*2/n_flow_watchers;
   if (ht_size < MIN_HT_SIZE) ht_size = MIN_HT_SIZE;

   flow_watcher_control_mem_init(n_flow_watchers);
   n_fw_running = 0;
   fw_next_st_to_check = n_flow_watchers;
   fwa = malloc(n_flow_watchers*sizeof(struct flow_watcher_control *));
   for (k = 0; k != n_flow_watchers; ++k) 
      fwa[k] = get_flow_watcher_control();

   /* Start flow-watching thread(s) */
#if STARTUP_DEBUG
   printf("start_meter(2.5):mx_source=%u, mx_fw=%u, ht_size=%u\n",
      source_active(), n_flow_watchers, ht_size);  //d
#endif
   for (k = 0; k != n_flow_watchers; ++k)
      start_flow_watcher(fwa[k], ht_size);
#if STARTUP_DEBUG
   printf("leaving iat_init() +-+\n");  fflush(stdout);
#endif
   log_msg(user_data, LOG_WARNING, 0, "Starting %s", IATversion);

   return IATversion;  /* From iat-conf.h */
   }
