/* iat-conf.h.  Generated from iat-conf.hin by configure.  */
/* 1036, Wed 27 Jun 12 (NZST)
   1345, Sun 27 May 12 (PDT)
   1112, Sat  3 Mar 12 (CET)
   1125, Tue 10 Jan 12 (NZDT)
   1139, Fri 21 May 10 (NZST)

   iat_conf.hin: Autoconf defines for iatmon

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2012 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#define IATversion  "2.2.2"

#define WORDS_BIGENDIAN     0
#define SIZEOF_LONG 8
#define SIZEOF_LONG_LONG 8
#define SIZEOF_TIME_T 8

#define RUBYv186 1

#define DFMXFLOWWATCHERS 1
#define SOURCETIMEOUTS 0
#define HALF_WAY_SOURCES 0
