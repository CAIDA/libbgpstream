/*//////////////////////////////////////////////////////////////////////
// File: semaphore.h
// --------------------------------------------------------------------
// This is a POSIX threads semaphore implementation.  See the docs
// at http://dis.cs.umass.edu/~wagner/threads_html/tutorial.html
// for information on POSIX threads and how to use this lib.
// --------------------------------------------------------------------
// Written by: Tom A. Wagner
//             wagner@cs.umass.edu
//             Multi-Agent Systems Lab
//             Department of Computer and Information Science
//             University of Massachusetts
//             Amherst, Massachusetts 01003.
//
// This code was written at the Multi-Agent Systems Lab. at the 
// Department of Computer Science, University of Massachusetts,
// Amherst, MA 01003.
//
// Copyright (c) 1996 UMASS CS Dept. All rights are reserved.
//
// Development of this code was partially supported by:
//    ONR grant N00014-92-J-1450
//    NSF grant IRI-9523419
//    DARPA grant, RaDEO program, 70NANB6H0074 as subcontractor for 
//          Boeing Helicoptor
////////////////////////////////////
//
//*/

#include <stdio.h>
#include <pthread.h>

#ifndef SEMAPHORES
#define SEMAPHORES

#define pthread_mutexattr_default  NULL  /* For Linux.  Nevil, 22 May 02 */
#define pthread_condattr_default   NULL
#define pthread_attr_default       NULL

typedef struct Semaphore
{
    int         v;
    pthread_mutex_t mutex;
    pthread_cond_t cond;
}
Semaphore;


int         t_semaphore_down (Semaphore * s);
int         t_semaphore_up (Semaphore * s);
void        t_semaphore_destroy (Semaphore * s);
void        t_semaphore_init (Semaphore * s);
int         t_semaphore_decrement (Semaphore * s);
int         t_semaphore_value (Semaphore * s);
/* semaphore_ routines changed to t_semaphore_
   to avoid conflict in Mac OSX.  Nevil 12 Jan 05 */
int         tw_pthread_cond_signal (pthread_cond_t * c);
int         tw_pthread_cond_wait (pthread_cond_t * c, pthread_mutex_t * m);
int         tw_pthread_mutex_unlock (pthread_mutex_t * m);
int         tw_pthread_mutex_lock (pthread_mutex_t * m);
void        do_error (char const *msg);

#endif
