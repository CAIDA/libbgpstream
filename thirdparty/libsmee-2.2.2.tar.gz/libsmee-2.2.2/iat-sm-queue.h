/* 1154, Wed 23 May 12 (PDT)

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2013 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/* Semaphore-managed producer-consumer queue, allowing
   the outer block (which may wait a long time) to be a consumer.
   Locks queue during push/pop, can have multiple producer threads.

   In these routines, think of the queue like an array;
   'head' is element 0, 'tail' is the highest-index element.

   Queue elements have *next in their object struct.

   [ gcc -E to only run preprocessor, -S to only compile ] */

/* (1) Declare global structs, usable in all .c files
   and templates for functions to work with them */

#define iat_smq_declare_globals(n) \
struct n##_smq { \
   struct n *head, *tail; \
   pthread_mutex_t mutex; \
   Semaphore non_empty; \
   uint32_t in_q, mx_in_q; \
   }; \
struct n *get_##n(void); \
void free_##n(struct n *object); \
\
void n##_smq_init(struct n##_smq *smq); \
uint32_t n##_smq_size(struct n##_smq *smq); \
uint32_t n##_mx_smq_size(struct n##_smq *smq); \
void n##_smq_push(struct n##_smq *smq, struct n *object);  \
struct n *n##_smq_shift(struct n##_smq *smq);  \

/* (2) Declare actual functions (matching the templates) */

#define iat_smq_declare_functions(n)  /* Queue methods */ \
struct n *get_##n(void) { \
   return (struct n *)malloc(sizeof(struct n)); \
   } \
void free_##n(struct n *object) { \
   free(object); \
   } \
void n##_smq_init(struct n##_smq *smq) { \
   smq->in_q = smq->mx_in_q = 0; \
   smq->head = smq->tail = NULL; \
   if (pthread_mutex_init(&smq->mutex, NULL) == -1) { \
      printf("Couldn't init smq mutex <<<\n");  exit(7); \
      } \
   t_semaphore_init(&smq->non_empty); \
   t_semaphore_decrement(&smq->non_empty);  /* Set v=0 */ \
   /* Don't bother with a destructor method */ \
   } \
uint32_t n##_smq_size(struct n##_smq *smq) { \
   return smq->in_q; \
   } \
uint32_t n##_mx_smq_size(struct n##_smq *smq) { \
   return smq->mx_in_q; \
   } \
void n##_smq_push(struct n##_smq *smq, struct n *object) { \
   struct n *old_tail = smq->tail; \
   pthread_mutex_lock(&smq->mutex); \
   old_tail = smq->tail;  object->next = NULL; \
   if (smq->tail != NULL) smq->tail->next = object; \
   else smq->head = object; \
   smq->tail = object; \
   __sync_fetch_and_add(&smq->in_q, 1); \
   if (smq->in_q > smq->mx_in_q) smq->mx_in_q = smq->in_q; \
   pthread_mutex_unlock(&smq->mutex); \
   t_semaphore_up(&smq->non_empty); \
   } \
extern struct n *n##_smq_shift(struct n##_smq *smq) { \
   struct n *object; \
   t_semaphore_down(&smq->non_empty); \
   pthread_mutex_lock(&smq->mutex); \
   if (smq->head == NULL) object = NULL;  /* 0 in queue */ \
   else { \
      object = smq->head; \
      if (smq->head == smq->tail)  /* 1 in queue */ \
         smq->head = smq->tail = NULL; \
      else  /* >1 in queue */ \
         smq->head = object->next; \
      object->next = NULL; \
      } \
   __sync_fetch_and_sub(&smq->in_q, 1); \
   pthread_mutex_unlock(&smq->mutex); \
   return object; \
   }

/* (3) Define variables within a .c file */

#define iat_smq_declare_space(q, n) \
struct n##_smq q
