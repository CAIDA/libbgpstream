
//  gcc -o sizes -DIATMON sizes.c

#include <stdint.h>

#include "iat.h"

int main() {
   printf("Sizes: source=%lu, source_info=%lu,  flow_info=%lu, distribution=%lu\n",
      (unsigned long)sizeof(struct source), 
      (unsigned long)sizeof(struct source_info),
      (unsigned long)sizeof(struct flow_info), 
      (unsigned long)sizeof(struct distribution));
   return 0;
   }
