/* 1154, Wed 23 May 12 (PDT)

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2013 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/* Lock-free, single-producer, single consumer queue based on a
   Dr Dobbs article, http://www.drdobbs.com/parallel/210604448?pgno=2

   In these routines, think of the queue like an array;
   'head' is element 0, 'tail' is the highest-index element.
   Producer owns nodes before 'divider,' consumer owns those
   from 'divider' to 'tail.'

   Queue elements have *next in their object struct.

   [ gcc -E to only run preprocessor, -S to only compile ] */


/* (1) Declare global structs, usable in all .c files
   and templates for functions to work with them */

#define iat_pcq_declare_globals(n) \
struct n##_pcq { \
   struct n *first, *divider, *last; \
   uint32_t in_q, mx_in_q; \
   }; \
\
void n##_pcq_init(struct n##_pcq *pcq); \
uint32_t n##_pcq_size(struct n##_pcq *pcq); \
uint32_t n##_mx_pcq_size(struct n##_pcq *pcq); \
void n##_pcq_push(struct n##_pcq *pcq, struct n *object); \
struct n *n##_pcq_shift(struct n##_pcq *pcq);

/* (2) Declare actual functions (matching the templates) */

#define iat_pcq_declare_functions(n)  /* Queue methods */ \
void n##_pcq_init(struct n##_pcq *pcq) { \
   pcq->in_q = pcq->mx_in_q = 0; \
   pcq->first = pcq->divider = pcq->last = get_##n(); \
   /* Don't bother with a destructor method */ \
   } \
uint32_t n##_pcq_size(struct n##_pcq *pcq) { \
   return pcq->in_q; \
   } \
uint32_t n##_mx_pcq_size(struct n##_pcq *pcq) { \
   return pcq->mx_in_q; \
   } \
void n##_pcq_push(struct n##_pcq *pcq, struct n *object) { \
   struct n *old_first; \
   if (pcq->in_q >= DFMXPWQUEUESZ) {  /* Don't get too far ahead! */ \
      for (;;) { \
         pthread_yield(); \
         if (pcq->in_q <= DFMXPWQUEUESZ*3/4) break; \
         } \
      } \
   __sync_fetch_and_add(&pcq->in_q, 1); \
   if (pcq->in_q > pcq->mx_in_q) pcq->mx_in_q = pcq->in_q; \
   pcq->last->next = object; \
   if (!__sync_bool_compare_and_swap( \
         &pcq->last, pcq->last, pcq->last->next)) \
      log_msg(user_data, LOG_ERR, 1, "pcq: failed to write last\n"); \
   while (pcq->first != pcq->divider) {  /* Recover now-unused nodes */ \
      old_first = pcq->first; \
      if (!__sync_bool_compare_and_swap( \
	     &pcq->first, pcq->first, pcq->first->next)) \
         log_msg(user_data, LOG_ERR, 1, "pcq: failed to write first\n"); \
      else free_##n(old_first);					\
      } \
   } \
struct n *n##_pcq_shift(struct n##_pcq *pcq) { \
   struct n *result; \
   for (;;) { \
      if (pcq->divider != pcq->last) { /* Queue nonempty */ \
         result = pcq->divider->next; \
	 __sync_bool_compare_and_swap( \
	    &pcq->divider, pcq->divider, pcq->divider->next); \
	 __sync_fetch_and_sub(&pcq->in_q, 1); \
	 return result; \
         } \
      else pthread_yield();  /* Queue empty */ \
      } \
   }

/* (3) Define variables within a .c file */

#define iat_pcq_declare_space(q, n) \
struct n##_pcq q
