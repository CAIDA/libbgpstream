/* 2358, Fri  1 Jun 12 (PDT)

   iat-smee.h: Interface definition for smee (the pirate mate), i.e.
               the interface for using iatmon in a Corsaro plugin

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2013 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef SMEE_COMMON  /* Things that Smee and Control both use */
#define SMEE_COMMON

#define MX_LOCAL_ADDRS  5
#define MXSTRMTXTLEN  250  /* Max length of a 'source txt' message */

struct v4_address {
   uint8_t ver, len;
   union {
      uint8_t a[4];
      uint32_t v4;
      } a;
   };
struct v6_address {
   uint8_t ver, len;
   union {
      uint8_t a[16];
      struct {
	 uint32_t q0, q1, q2, q3;
         uint64_t oct0, oct1;
         } o;
      } a;
   };
struct ip_address {
   uint8_t ver, len;
   union a {
      uint32_t v4;
      uint8_t a[16];
      struct o {
	 uint32_t q0, q1, q2, q3;
         uint64_t oct0, oct1;
         } o;
      } a;
   };

char *iat_init(const char *trace_name,  /* Tue, 5 Mar 13 (PST) */
      const char *c_meter_loc, int c_mx_life, int c_mx_sources,
      int c_time_rec_interval,
      struct ip_address *c_local_addrs, int c_n_local_addrs,
      void *c_user_data,
      void (*c_log_msg)(void *user_data, int priority, int die, 
         char const *fmt, ...),
      int (*c_stat_printf)(void *user_data, const char *fmt, ...),
      int (*c_sum_printf)(void *user_data, const char *fmt, ...),
      int (*c_sources_printf)(void *user_data, const char *fmt, ...),
      uint64_t (*c_pkt_drops)(void *user_data));

/*  Returns IATversion (for Ruby OB to write summary file) */


int iat_process_packet(libtrace_packet_t *packet, int action_req);

/* IATMON: Call with NULL packet to signal EOF, returns one of: */
#define SM_OK               0  /* process_packet return codes */
#define SM_STOP_REQUEST     1
#define SM_RECORD_INTERVAL  2  /* Time to write summary file */

/* Smee: Corsaro passes in action_request: */
#define SM_PACKET           0  /* Just process the packet */
#define SM_RECORD_REQ       1  /* Time to write a summary file */
#define SM_DUMMY            2

/* Caller knows the last packet's time (Unix seconds), so after
   a summary file has been written, it can decide the name of the 
   next summary file to be written.  */


#define S_unclassified          0  /* Type Numbers */

#define S_tcp_probe             1
#define S_tcp_vertical_scan     2
#define S_tcp_horizontal_scan   3
#define S_tcp_unknown           4

#define S_udp_probe             5
#define S_udp_vertical_scan     6
#define S_udp_horizontal_scan   7
#define S_udp_unknown           8

#define S_icmp_only             9
#define S_old_backscatter      10
#define S_tcp_and_udp          11

#define S_utorrent             12
#define S_conficker_c          13
#  define CFC_FRACTION  3/4
#define S_1_or_2_packets       14

#define S_backscatter_tcp      15
#define S_backscatter_dns      16
#define S_backscatter_icmp     17

#if !NON_CONF_TEST
#define S_tcp_445_horiz_scan   18
#define N_source_types         19
#else
#define S_t445_dest_cfab       18
#define S_t445_dest_random     19
#define S_t445_dest_other      20

#define S_tcfc_dest_cfab       21  /* These subdivide S_conficker_c */
#define S_tcfc_dest_random     22
#define S_tcfc_dest_other      23
#define N_source_types         24

#define CFC_EPSILON_PC   0.02  /* Allow for random behavior in tests */
#endif

#  define MIN_pkts_to_classify  3

#define IAT_Other               0  /* Group Numbers */
#define IAT_short_lived         1
#define IAT_high_rate           2  /* > 5 pkt/s */
#define IAT_DOS                 3

#define IAT_3_left              4
#define IAT_3_even              5
#define IAT_3_right             6

#define IAT_stealth_3s_mode     7  /* Long-lived, few pkts */
#define IAT_stealth_spikes      8
#define IAT_stealth             9

#define N_source_groups        10


#endif  /* SMEE_COMMON */
