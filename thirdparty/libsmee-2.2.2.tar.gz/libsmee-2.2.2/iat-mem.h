/* 1154, Wed 23 May 12 (PDT)
   1120, Mon 21 May 12 (PDT)

   iatmon/owtmon: One-Way Traffic Monitor testbed
   Copyright (C) 2009-2013 by Nevil Brownlee, U Auckland | CAIDA | WAND

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/* Memory management for iatmon, using malloc()/free() instead of
   using queues of linked objects (as in NeTraMet, ua-meter and owtmon)

   [ gcc -E to only run preprocessor, -S to only compile ] */


/* (1) Declare global structs, usable in all .c files
   and templates for functions to work with them */

#define iat_mem_declare_globals(n) \
struct n##_mem { \
   uint32_t active, mx_allowed; \
   }; \
\
struct n *get_##n(void); \
void free_##n(struct n *object); \
\
void n##_mem_init(uint32_t mx_objects); \
uint32_t n##_active(void); \
uint32_t n##_allowed(void);

/* (2) Declare actual functions (matching the templates) */

#define iat_mem_declare_functions(n)  /* Queue methods */ \
struct n##_mem n##_mgr;  /* Watches nbr of active objects */ \
\
struct n *get_##n(void) { \
   struct n *r; \
   r = (struct n *)malloc(sizeof(struct n)); \
   if (r)  __sync_fetch_and_add(&n##_mgr.active, 1); \
   return r; \
   } \
void free_##n(struct n *object) { \
   free(object); \
   __sync_fetch_and_sub(&n##_mgr.active, 1); \
   } \
void n##_mem_init(uint32_t mx_objects) { \
   n##_mgr.active = 0;  n##_mgr.mx_allowed = mx_objects; \
   } \
uint32_t n##_active(void) { \
   return n##_mgr.active; \
   } \
uint32_t n##_allowed(void) { \
   return n##_mgr.mx_allowed; \
   }
